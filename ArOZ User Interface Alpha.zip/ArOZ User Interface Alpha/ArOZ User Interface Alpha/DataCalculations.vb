﻿Imports System.IO

Public Class DataCalculations
    Function substringlast(ByVal Input As String, ByVal divder As String)
        On Error Resume Next

        Dim divderpos As Integer = 0
        divderpos = Input.LastIndexOf(divder)

        Dim result As String = Input.Substring(divderpos + 1, Input.Length - divderpos - 1)
        Return result
    End Function

    Function ReadFileContain(ByVal Filename As String, ByVal Contain As String)
        On Error Resume Next
        Dim code As String = Nothing
        If System.IO.File.Exists(Filename) = True Then

            Dim objReader As New System.IO.StreamReader(Filename, System.Text.Encoding.GetEncoding(950))

            Do While objReader.Peek() <> -1

                code = objReader.ReadLine() & vbNewLine
                If code.Contains(Contain) Then
                    objReader.Dispose()
                    Return code
                End If
            Loop
            objReader.Dispose()
        Else
            Debugger.sendtodebugger("DataCalulator", "READ ERROR")
            Return Nothing
        End If
    End Function

    Function ReadFileRandom(ByVal Filename As String)
        On Error Resume Next
        Dim linecount As Integer = 0
        Dim code As String = Nothing
        If System.IO.File.Exists(Filename) = True Then

            linecount = File.ReadAllLines(Filename).Length
        Else
            Debugger.sendtodebugger("DataCalulator", "READ ERROR")
            Return Nothing
        End If
        Debugger.sendtodebugger("DataCalulator", linecount)
        Dim rnd As Integer = Randomnumber(0, linecount)
        Debugger.sendtodebugger("DataCalulator", "Found " & linecount & "In The File, Random Reading..")

        Dim content As String = Nothing
        If System.IO.File.Exists(Filename) = True Then
            Dim objReader As New System.IO.StreamReader(Filename, System.Text.Encoding.GetEncoding(950))
            Do While objReader.Peek() <> -1
                content = objReader.ReadLine()
                If content.Contains("[" & rnd & "]:") Then
                    content = content.Replace("[" & rnd & "]:", "")
                    objReader.Dispose()
                    Return content
                End If
            Loop
            objReader.Dispose()
        Else
            Debugger.sendtodebugger("DataCalulator", "READ ERROR")
            Return Nothing
        End If

        Return content
    End Function

    Public Function Randomnumber(ByVal startfrom As Integer, ByVal endat As Integer)
        'Generate Random Number
        Dim num As Integer = 0
        Dim Generator As System.Random = New System.Random()
        num = Generator.Next(startfrom, endat)
        Return num
    End Function

    Public Function GetSystemTime()
        Dim time As String = "nill"
        Dim timehandler As New ArOZ.ArOZTimeHandler
        time = timehandler.getmonth & "月 " & timehandler.getday & "日 " & timehandler.gethour & "時 " & timehandler.getmin & "分"
        Return time
    End Function
End Class
