﻿Public Class Inputbox
    Private IsFormBeingDragged As Boolean = False
    Private MouseDownX As Integer
    Private MouseDownY As Integer
    Dim defindlocation As Point
    Dim shutdown As Boolean = False
    Dim edjustrelativedistant As Boolean = False
    Dim z As String
    Dim enterpressed As Boolean = False
    Dim specialmessage As Boolean = False





    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseDown, PictureBox1.MouseDown
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = True
            MouseDownX = e.X
            MouseDownY = e.Y
        End If
    End Sub



    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseUp, PictureBox1.MouseUp
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = False
            If edjustrelativedistant = True Then
                Dim temp As Point
                temp.X = Me.Location.X
                Dim returnpoint As Point = ArOZInterface.ReturnPosition()
                Debugger.sendtodebugger(Me.Text, returnpoint.X & returnpoint.Y)
                temp.X = returnpoint.X - Me.Location.X
                temp.Y = Me.Location.Y - returnpoint.Y
                Debugger.sendtodebugger(Me.Text, temp.X & temp.Y)
                My.Settings.Inputboxrelativlocation = temp
                My.Settings.Save()
                edjustrelativedistant = False
                Timer2.Enabled = True
            End If

        End If
    End Sub


    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseMove, PictureBox1.MouseMove
        If IsFormBeingDragged Then
            Dim temp As Point = New Point()
            temp.X = Me.Location.X + (e.X - MouseDownX)
            temp.Y = Me.Location.Y + (e.Y - MouseDownY)
            Me.Location = temp
            temp = Nothing
            Timer2.Enabled = False
            edjustrelativedistant = True
        End If
    End Sub
    Private Sub ReplyBox_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim temp As Point
        temp = ArOZInterface.ReturnPosition()
        temp.X -= 260
        temp.Y += 0
        Debugger.sendtodebugger(Me.Text, temp.X & temp.Y)
        Me.Location = temp
        TextBox1.Parent = PictureBox1

        defindlocation = Me.Location
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Dim temp As Point
        temp = ArOZInterface.ReturnPosition()
        temp.X -= My.Settings.Inputboxrelativlocation.X
        temp.Y += My.Settings.Inputboxrelativlocation.Y

        Me.Location = temp
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub


    Private Sub TextBox1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox1.KeyDown
        If e.KeyCode = Keys.Enter Then
            MsgBox("enter key pressd ")
        End If

    End Sub

    Private Sub TextBox1_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.Leave

    End Sub
End Class