﻿Imports System.Text.Encoding
Imports System.Reflection
Imports System.Net.Sockets
Imports System.Net

Public Class ArOZ_NetHost
    Dim WithEvents Host As ArOZ_Network.Host
    Dim enableserver As Boolean = False
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        On Error Resume Next
        If enableserver = False Then
            enableserver = True
            Host = New ArOZ_Network.Host(NumericUpDown1.Value)
            Host.StartConnection()
            Button1.Text = "中止連接"
            TextBox1.AppendText("已開啟ArOZ區網連接系統。" & vbNewLine)
            Timer1.Enabled = True
            PictureBox1.BackColor = Color.Lime
            NumericUpDown1.Enabled = False
        Else
            enableserver = False
            Host.CloseConnection()
            Button1.Text = "開始連接"
            TextBox1.AppendText("已關閉ArOZ區網連接系統。" & vbNewLine)
            Timer1.Enabled = False
            Timer2.Enabled = False
            PictureBox1.BackColor = Color.Red
            NumericUpDown1.Enabled = True

        End If
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Host.CloseConnection()
    End Sub
    Private Sub Form1_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        On Error Resume Next
        TextBox1.Enabled = False
        TextBox1.AppendText(">>伺服器界面開啟<<" & vbNewLine)

    End Sub

    Private Sub DataReceived(ByVal ID As String, ByVal Data() As Byte) Handles Host.DataReceived
        On Error Resume Next
        TextBox1.AppendText(ID & ": " & ArOZ_Network.Host.ConvertFromAscii(Data) & vbNewLine)
        Host.Brodcast(ArOZ_Network.Host.Convert2Ascii(ID & ": " & ArOZ_Network.Host.ConvertFromAscii(Data)))
    End Sub
    Private Sub DataTransferred(ByVal Sender As String, ByVal Recipient As String, ByVal Data() As Byte) Handles Host.DataTransferred
        TextBox1.AppendText(Sender & " 傳送資料到 " & Recipient & ": " & ArOZ_Network.Host.ConvertFromAscii(Data) & vbNewLine)
    End Sub
    Public Sub onConnection(ByVal ID As String) Handles Host.onConnection
        TextBox1.AppendText(ID & " 已連接" & vbNewLine)
        Host.Brodcast(ArOZ_Network.Host.Convert2Ascii(ID & " 已連接"))
    End Sub
    Private Sub lostConnection(ByVal ID As String) Handles Host.lostConnection
        TextBox1.AppendText(ID & " 已離線" & vbNewLine)
        Host.Brodcast(ArOZ_Network.Host.Convert2Ascii(ID & " 已離線"))
    End Sub
    Private Sub errHandler(ByVal ex As Exception) Handles Host.errEncounter

    End Sub

    Private Sub ArOZ_NetHost_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        On Error Resume Next
        TextBox1.AppendText(">>伺服器界面已載入<<" & vbNewLine)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        On Error Resume Next
        PictureBox2.BackColor = Color.Lime
        PictureBox3.BackColor = Color.Lime
        Timer2.Enabled = True
        Timer1.Enabled = False

    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        On Error Resume Next
        PictureBox2.BackColor = Color.MediumBlue
        PictureBox3.BackColor = Color.Firebrick
        Timer2.Enabled = False
        Timer1.Enabled = True
    End Sub

    ' Public Shared Function AddressInfoFromTCPClient(ByVal theClient As TcpClient) As AddressInfo
    'Dim pi As PropertyInfo = theClient.GetStream.GetType.GetProperty("Socket", _
    '                        BindingFlags.NonPublic Or BindingFlags.Instance)
    'Dim theSocket As Socket = pi.GetValue(theClient.GetStream, Nothing)
    'Dim theEnd As EndPoint = theSocket.RemoteEndPoint
    'Dim theAddress() As String = theEnd.ToString.Split(":")
    'Dim theInfo As New AddressInfo(theAddress(0), theAddress(1))
    '    Return theInfo
    'End Function
End Class