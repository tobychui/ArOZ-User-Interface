﻿Imports ArOZ
Public Class ArOZInterface

    Dim appPath As String = Application.StartupPath()
    Dim face As New InterfaceHandler
    Private IsFormBeingDragged As Boolean = False

    Private MouseDownX As Integer

    Private MouseDownY As Integer

    Dim z As String

    Dim ground As Integer
    ' When Load up, handle basic information

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        On Error Resume Next
     

        Me.TopMost = True
        Me.TopLevel = True
        'Check it the user is first login
        If My.Computer.FileSystem.DirectoryExists(appPath & "\database") = False Or My.Computer.FileSystem.DirectoryExists(appPath & "\ghost") = False Then
            CreateLeaningLib()
        End If

        'Explode the stuff out
      

        If checkfirstlog() = True Then
            Dim Login As New ArOZ.ArOZLoginTaskHandler
            Chatbox.displaytext(Login.firstmessage(), -2, 1)
            Answerbox.getspecialreturn(1)
            If checkfirstlog() = False Then
                Talk.Enabled = True
            End If
        End If


        Dim x As Integer
        Dim y As Integer
        x = Screen.PrimaryScreen.WorkingArea.Width
        y = Screen.PrimaryScreen.WorkingArea.Height - PictureBox1.Height + 10

        Do Until x = Screen.PrimaryScreen.WorkingArea.Width - PictureBox1.Width - 40
            x = x - 1
            Me.Location = New Point(x, y)
        Loop
        ground = y
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        'see what ghost to use
        If My.Settings.GhostLocation = "/default/" Then
            PictureBox1.BackgroundImage = Image.FromFile(My.Settings.GhostLocation & "\1.png")
        Else
            face.setinterface(1, False)
        End If


        'After getting the event postion, Start to communicate with users

     




    End Sub
    'Send position to other Forms and let them appera in correct place
    Public Function ReturnPosition()
        On Error Resume Next
        Dim returnpos As Point

        returnpos = Me.Location

        Return returnpos
    End Function

    Private Sub ArOZ_Shut(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.Leave
        Launch.Close()
    End Sub





    'Handle Right Click and left click on the case
    Private Sub PictureBox1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseDown



        If e.Button = MouseButtons.Left Then

            IsFormBeingDragged = True

            MouseDownX = e.X

            MouseDownY = e.Y



        End If

    End Sub

    Private Sub PictureBox1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseUp, PictureBox1.MouseClick
        On Error Resume Next
        If e.Button = Windows.Forms.MouseButtons.Right Then

            Menubar.Show()

            'Dim cms = New ContextMenuStrip
            'Dim item1 = cms.Items.Add("設定")
            'item1.Tag = 1
            'AddHandler item1.Click, AddressOf menuChoice
            'Dim item2 = cms.Items.Add("bar")
            'item2.Tag = 2
            'AddHandler item2.Click, AddressOf menuChoice
            'Dim item3 = cms.Items.Add("隱藏")
            'item3.Tag = 3
            'AddHandler item3.Click, AddressOf menuChoice
            'Dim item4 = cms.Items.Add("再見~")
            'item4.Tag = 4
            'AddHandler item4.Click, AddressOf menuChoice
            'Dim temp As Point = New Point()

            'temp.X = 140 ' Higer the value is, further the postion is
            'temp.Y = 30 'Lower the value is, Higer the position is
            'cms.Show(PictureBox1, temp)

            'Following Command only for debug
            'MsgBox(e.Location.X & e.Location.Y)
        End If



        If e.Button = MouseButtons.Left Then



        End If

    End Sub

    Private Sub menuChoice(ByVal sender As Object, ByVal e As EventArgs)
        On Error Resume Next
        Dim item = CType(sender, ToolStripMenuItem)
        Dim selection = CInt(item.Tag)

        If selection = 1 Then
        ElseIf selection = 2 Then
        ElseIf selection = 3 Then
            PictureBox1.Visible = False
            NotifyIcon1.Visible = True
        ElseIf selection = 4 Then

            Me.Close()
        End If
    End Sub

    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseDown, PictureBox1.MouseDown
        On Error Resume Next
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = True
            MouseDownX = e.X
            MouseDownY = e.Y
        End If

    End Sub



    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseUp, PictureBox1.MouseUp
        On Error Resume Next


        If e.Button = MouseButtons.Left Then

            IsFormBeingDragged = False

        End If

    End Sub



    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseMove, PictureBox1.MouseMove

        On Error Resume Next
        If IsFormBeingDragged Then

            Dim temp As Point = New Point()



            temp.X = Me.Location.X + (e.X - MouseDownX)

            temp.Y = Me.Location.Y + (e.Y - MouseDownY)
            Me.Location = temp

            temp = Nothing

        End If

    End Sub

    Private Sub NotifyIcon1_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles NotifyIcon1.MouseDoubleClick, NotifyIcon1.MouseDown
        On Error Resume Next
        If e.Button = Windows.Forms.MouseButtons.Right Then

            Dim cms = New ContextMenuStrip
            Dim item1 = cms.Items.Add("設定")
            item1.Tag = 1
            AddHandler item1.Click, AddressOf menuChoice
            Dim item2 = cms.Items.Add("bar")
            item2.Tag = 2
            AddHandler item2.Click, AddressOf menuChoice
            Dim item3 = cms.Items.Add("隱藏")
            item3.Tag = 3
            AddHandler item3.Click, AddressOf menuChoice
            Dim item4 = cms.Items.Add("再見~")
            item4.Tag = 4
            AddHandler item4.Click, AddressOf menuChoice
            Dim temp As Point = New Point()
            temp = MousePosition()

            cms.Show(PictureBox1, temp)

            'Following Command only for debug
            MsgBox(e.Location.X & e.Location.Y)
        End If
        PictureBox1.Visible = False
    End Sub


    Public Sub CreateLeaningLib()

   
        Dim timehandler As New ArOZ.ArOZTimeHandler

        Dim randomnumber As Integer = 0
        Dim Generator As System.Random = New System.Random()
        randomnumber = Generator.Next(1234, 1780)


        Dim key As String = (randomnumber & "-" & randomnumber / 10 * 9.81 & "-" & timehandler.getday & timehandler.getmonth)


        Dim time As New ArOZ.ArOZTimeHandler
        Dim sc As New System.Text.StringBuilder
        sc.AppendLine("Firest_Launch_Month:" & time.getmonth)
        sc.AppendLine("Firest_Launch_day:" & time.getday)
        sc.AppendLine("Firest_Launch_Year:" & time.getyear)
        sc.AppendLine("Launchkey:" & key)
        Try
            IO.File.WriteAllText((appPath & "\database\Basics\memory.aroz"), sc.ToString(), System.Text.Encoding.GetEncoding(950))
        Catch ex As Exception

        End Try

        Try
            Dim file As New ArOZFileHandler
            If file.checkifexits(appPath & "\ghost\interface.dat") = False Then
                IO.File.WriteAllText((appPath & "\ghost\interface.dat"), "1", System.Text.Encoding.GetEncoding(950))

            End If
            If file.checkifexits(appPath & "\database\Basics\aroz.temp") = False Then
                IO.File.WriteAllText((appPath & "\database\Basics\aroz.temp"), "/* If you see this line, that means this file is all right. */", System.Text.Encoding.GetEncoding(950))

            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Function checkfirstlog()
        On Error Resume Next
        Dim firstlog As Boolean = False
        If My.Settings.UserName = Nothing Or My.Settings.AIName = Nothing Then
            firstlog = True
            My.Settings.GhostLocation = appPath & "\ghost\Aliz"
        ElseIf My.Settings.AIName <> Nothing And My.Settings.UserName <> Nothing Then
            '即是說玩家名稱和ArOZ 名稱都定好之後…
            Dim file As New ArOZFileHandler
            Dim timehandler2 As New ArOZ.ArOZTimeHandler
            If file.checkifexits(appPath & "\database\Plugins\information.aroz") = True Then
                System.IO.File.Delete(appPath & "\database\Plugins\information.aroz")
            End If
            If file.checkifexits(appPath & "\database\Plugins\datim.aroz") = True Then
                System.IO.File.Delete(appPath & "\database\Plugins\datim.aroz")
            End If
            Dim sc As New System.Text.StringBuilder
            sc.AppendLine("UserName=" & My.Settings.UserName)
            sc.AppendLine("AIName=" & My.Settings.AIName)
            sc.AppendLine("LastMeetCode=" & timehandler2.meetinteval(My.Settings.lastmeetmin, My.Settings.lastmeethour, My.Settings.lastmeetday, My.Settings.lastmeetmonth, My.Settings.lastmeetyear))
            sc.AppendLine("ApplicationStartupPath=" & appPath & "\database\Plugins\")
            sc.AppendLine("ChatboxRelativeLocationX=" & My.Settings.ChatboxreletiveLocation.X)
            sc.AppendLine("ChatboxRelativeLocationY=" & My.Settings.ChatboxreletiveLocation.Y)
            sc.AppendLine("InputboxRelativeLocationX=" & My.Settings.Inputboxrelativlocation.X)
            sc.AppendLine("InputboxRelativeLocationY=" & My.Settings.Inputboxrelativlocation.Y)

            IO.File.WriteAllText((appPath & "\database\Plugins\information.aroz"), sc.ToString, System.Text.Encoding.GetEncoding(950))
            Dim sb As New System.Text.StringBuilder
            sb.AppendLine("DisplayText=")
            sb.AppendLine("ExternalAction=")
            IO.File.WriteAllText((appPath & "\database\Plugins\datim.aroz"), sb.ToString, System.Text.Encoding.GetEncoding(950))
        End If

        Return firstlog
    End Function

    Private Function eyernd()
        'Generate Random Number
        Dim num As Integer
        Dim Generator As System.Random = New System.Random()
        num = Generator.Next(150, 300)
        Return num
    End Function

    Private Function blinkrnd()
        'Generate Random Number
        Dim num As Integer
        Dim Generator As System.Random = New System.Random()
        num = Generator.Next(3000, 5000)
        Return num
    End Function

    Private Sub Chcktempfile_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Chcktempfile.Tick
        'Check if those plugins required to display anythings on Display Box
        On Error Resume Next
        Dim face As Integer = 1
        Dim data As New DataCalculations
        If My.Computer.FileSystem.FileExists(appPath & "\database\Plugins\datim.aroz") = False Then
            Dim sb As New System.Text.StringBuilder
            sb.AppendLine("DisplayText=")
            sb.AppendLine("ExternalAction=")
            IO.File.WriteAllText((appPath & "\database\Plugins\datim.aroz"), sb.ToString, System.Text.Encoding.GetEncoding(950))
        Else
            Dim displaytext As String = data.ReadFileContain(appPath & "\database\Plugins\datim.aroz", "DisplayText=")
            Dim externalAction As String = data.ReadFileContain(appPath & "\database\Plugins\datim.aroz", "ExternalAction=")
            displaytext = displaytext.Replace("DisplayText=", "")
            externalAction = externalAction.Replace("ExternalAction=", "")

            If displaytext.Length > 2 Then

                If displaytext.Contains("ff&*") And displaytext.Contains("*&ff") Then
                    displaytext = displaytext.Replace("ff&*", Nothing)
                    displaytext = displaytext.Replace("*&ff", Nothing)
                    Debugger.sendtodebugger(Me.Text, "Temp File Face Details = " & displaytext.Substring(displaytext.Length - 3, 1))
                    face = displaytext.Substring(displaytext.Length - 3, 1)
                    displaytext = displaytext.Substring(0, displaytext.Length - 3)
                Else
                    face = 1
                End If
                Debugger.sendtodebugger(Me.Text, "Display Text Value =  " & displaytext)
                displaytext = displaytext.Substring(0, displaytext.Length)
                Chatbox.displaytext(displaytext, -2, face)
            End If

            If externalAction.Length > 1 Then

            End If
        End If




    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        On Error Resume Next
        Dim ginterface As String = face.getinterface()
        Dim blinking As Integer = eyernd()
        Blink.Interval = blinking
        Debugger.sendtodebugger(Me.Text, "Eye Close For " & blinking & "ms")
        If ginterface <> "error" Then
            face.setinterface(ginterface, True)
        End If

        Blink.Start()
        Timer1.Enabled = False
    End Sub

    Private Sub Blink_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Blink.Tick
        On Error Resume Next
        Dim interfacenumber As String = face.getinterface()
        Dim setface As String
        If interfacenumber.Contains("_c") Then
            setface = interfacenumber.Replace("_c", "")
            face.setinterface(setface, False)
            Blink.Enabled = False
            Dim blinknum As Integer = blinkrnd()
            Timer1.Interval = blinknum
            Debugger.sendtodebugger(Me.Text, "Blink for " & blinknum & "ms")
            Timer1.Enabled = True
        End If
    End Sub

    Private Sub Talk_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Talk.Tick
        If My.Settings.SelfTakInteval = 0 Then

        Else
            Dim com As New Communication
            com.SelfTalk()
            Debugger.sendtodebugger(Me.Text, "Require for SELFTALK")
        End If
        Talk.Interval = My.Settings.SelfTakInteval * 1000
    End Sub


End Class
