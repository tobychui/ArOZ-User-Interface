﻿Imports ArOZ
Public Class Chatbox
    Private IsFormBeingDragged As Boolean = False
    Private MouseDownX As Integer
    Private MouseDownY As Integer
    Dim defindlocation As Point
    Dim shutdown As Boolean = False
    Dim edjustrelativedistant As Boolean = False
    Dim z As String
    Dim FileHandler As New ArOZFileHandler
    Dim Interfacehandler As New InterfaceHandler


    Public Sub displaytext(ByVal message As String, ByVal lovevalue As Integer, ByVal Action As Integer)
        Me.Show()
        Timer1.Enabled = False
        Timer1.Enabled = True
        If message <> "" And lovevalue = -2 Then
            Label1.Text = message
        End If
        Dim ghostlocation As String = Nothing
        If My.Settings.GhostLocation <> "/default/" Then
            ghostlocation = My.Settings.GhostLocation
        Else
            ghostlocation = Application.StartupPath & "\ghost\Aliz"
        End If
        Try
            Select Case Action
                Case Is = 1
                    Interfacehandler.setinterface(1, False)
                Case Is = 2
                    Interfacehandler.setinterface(2, False)
                Case Is = 3
                    Interfacehandler.setinterface(3, False)
            End Select
        Catch ex As Exception

        End Try

    End Sub




    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseDown, PictureBox1.MouseDown, Label1.MouseDown
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = True
            MouseDownX = e.X
            MouseDownY = e.Y
        End If
    End Sub



    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseUp, PictureBox1.MouseUp, Label1.MouseUp
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = False
            If edjustrelativedistant = True Then
                Dim temp As Point
                temp.X = Me.Location.X
                Dim returnpoint As Point = ArOZInterface.ReturnPosition()
                Debugger.sendtodebugger(Me.Text, returnpoint.X & returnpoint.Y)
                temp.X = returnpoint.X - Me.Location.X
                temp.Y = Me.Location.Y - returnpoint.Y
                Debugger.sendtodebugger(Me.Text, temp.X & temp.Y)
                My.Settings.ChatboxreletiveLocation = temp
                My.Settings.Save()
                edjustrelativedistant = False
                Timer2.Enabled = True
            End If

        End If
    End Sub


    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseMove, PictureBox1.MouseMove, Label1.MouseMove
        If IsFormBeingDragged Then
            Dim temp As Point = New Point()
            temp.X = Me.Location.X + (e.X - MouseDownX)
            temp.Y = Me.Location.Y + (e.Y - MouseDownY)
            Me.Location = temp
            temp = Nothing
            Timer2.Enabled = False
            edjustrelativedistant = True
        End If
    End Sub
    Private Sub ReplyBox_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim temp As Point
        temp = ArOZInterface.ReturnPosition()
        temp.X -= 260
        temp.Y += 0
        Debugger.sendtodebugger(Me.Text, temp.X & temp.Y)
        Me.Location = temp
        Label1.Parent = PictureBox1
        Timer1.Interval = My.Settings.Chatboxinterval * 1000
        defindlocation = Me.Location
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Timer1.Enabled = False
        Dim face As New InterfaceHandler
        face.setinterface(1, False)
        If shutdown = True Then
            ArOZInterface.Close()
        End If

        Me.Hide()
        Label1.Text = ""
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Dim temp As Point
        temp = ArOZInterface.ReturnPosition()
        temp.X -= My.Settings.ChatboxreletiveLocation.X
        temp.Y += My.Settings.ChatboxreletiveLocation.Y

        Me.Location = temp
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Chatbox_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.DoubleClick, PictureBox1.DoubleClick, Label1.DoubleClick
        Me.Hide()
    End Sub
End Class