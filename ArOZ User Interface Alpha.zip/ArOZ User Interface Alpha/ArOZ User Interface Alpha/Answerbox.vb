﻿Public Class Answerbox
    Private IsFormBeingDragged As Boolean = False
    Private MouseDownX As Integer
    Private MouseDownY As Integer
    Dim defindlocation As Point
    Dim shutdown As Boolean = False
    Dim edjustrelativedistant As Boolean = False
    Dim z As String
    Dim enterpressed As Boolean = False
    Dim specialmessage As Boolean = False
    Dim formreturncode As Integer = 0
    Dim username As String
    Dim link As Boolean = False





    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseDown, PictureBox1.MouseDown
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = True
            MouseDownX = e.X
            MouseDownY = e.Y
        End If
    End Sub



    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseUp, PictureBox1.MouseUp
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = False
            If edjustrelativedistant = True Then
                Dim temp As Point
                temp.X = Me.Location.X
                Dim returnpoint As Point = ArOZInterface.ReturnPosition()
                Debugger.sendtodebugger(Me.Text, returnpoint.X & returnpoint.Y)
                temp.X = returnpoint.X - Me.Location.X
                temp.Y = Me.Location.Y - returnpoint.Y
                Debugger.sendtodebugger(Me.Text, temp.X & temp.Y)
                My.Settings.Anserboxrelativdistant = temp
                My.Settings.Save()
                edjustrelativedistant = False
                Timer2.Enabled = True
            End If

        End If
    End Sub


    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseMove, PictureBox1.MouseMove
        If IsFormBeingDragged Then
            Dim temp As Point = New Point()
            temp.X = Me.Location.X + (e.X - MouseDownX)
            temp.Y = Me.Location.Y + (e.Y - MouseDownY)
            Me.Location = temp
            temp = Nothing
            Timer2.Enabled = False
            edjustrelativedistant = True
        End If
    End Sub
    Private Sub ReplyBox_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim temp As Point
        temp = ArOZInterface.ReturnPosition()
        temp.X -= 260
        temp.Y += 0
        Debugger.sendtodebugger(Me.Text, temp.X & temp.Y)
        Me.Location = temp
        TextBox1.Parent = PictureBox1

        defindlocation = Me.Location
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub



    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Dim temp As Point
        temp = ArOZInterface.ReturnPosition()
        temp.X -= My.Settings.Anserboxrelativdistant.X
        temp.Y += My.Settings.Anserboxrelativdistant.Y

        Me.Location = temp
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox1.KeyDown
        On Error Resume Next
        If e.KeyCode = Keys.Enter Then
            enterpressed = True
            Debugger.sendtodebugger(Me.Text, enterpressed)
            Dim login As New ArOZ.ArOZLoginTaskHandler
            Dim x As Integer = 0
            If formreturncode = 1 Then 'Ask for user name

                username = login.getusername(TextBox1.Text)
                If Name = "你慢慢想一下，我在這裡等你~" Or Name = "慢慢想，不用急的~" Or Name = "要想麼？" Or Name = "呵呵~ 就個名字而已還要想嗎？" Or Name = "請告訴我，你的名字是？" Then
                    Chatbox.displaytext(Name, -2, 2)
                Else
                    Chatbox.displaytext(username & " ，這樣好嗎？", -2, 2)
                    formreturncode = 2 ' Ask for confirm code
                    Debugger.sendtodebugger(Me.Text, "FormReturn Code = " & formreturncode)
                End If
                enterpressed = False
                TextBox1.Text = Nothing
            ElseIf formreturncode = 2 Then 'Get confirm
                Dim confirm As String = login.getconfirm(TextBox1.Text, x)
                If confirm = "True" Then
                    Chatbox.displaytext(username & " ，請多多指教呢！", -2, 1)
                    formreturncode = 3 'Continue next question or commands
                    Debugger.sendtodebugger(Me.Text, "FormReturn Code = " & formreturncode)
                    My.Settings.UserName = username
                    My.Settings.Save()
                    link = True
                    Linkage.Enabled = True
                ElseIf confirm = "False" Then
                    x += 1
                    Chatbox.displaytext("那，我應該怎樣稱呼您？", -2, 1)
                    formreturncode = 1 ' Ask the user name again
                    Debugger.sendtodebugger(Me.Text, "FormReturn Code = " & formreturncode)

                Else
                    Dim errormsg As New ArOZ.ArOZUnknownMessageHandler
                    Chatbox.displaytext(errormsg.geterrormsg(1).ToString, -2, 1)
                End If
                TextBox1.Text = Nothing
                enterpressed = False
            ElseIf formreturncode = 5 Then ' change name (True or False)
                Dim m As String = TextBox1.Text
                Dim good As Boolean = login.getconfirm(m, 1)
                If good = True Then
                    Chatbox.displaytext(My.Settings.UserName & " ，你以後要叫我 艾麗絲  ~", -2, 3)
                    Debugger.sendtodebugger(Me.Text, "FormReturn Code = " & formreturncode)
                    My.Settings.AIName = "艾麗絲"
                    My.Settings.Save()
                    ArOZInterface.Talk.Enabled = True
                    formreturncode = 0
                Else
                    Chatbox.displaytext("那你想怎樣叫我？", -2, 3)
                    formreturncode = 6
                    Debugger.sendtodebugger(Me.Text, "FormReturn Code = " & formreturncode)
                End If
                TextBox1.Text = Nothing
            ElseIf formreturncode = 6 Then 'Confirm for changing name
                Dim m As String = TextBox1.Text
                Dim name As String = login.getusername(m)
                Chatbox.displaytext(name & " ，是這樣嗎？", -2, 1)
                formreturncode = 7
                Debugger.sendtodebugger(Me.Text, "FormReturn Code = " & formreturncode)
                TextBox1.Text = Nothing
                My.Settings.AIName = name
                My.Settings.Save()
            ElseIf formreturncode = 7 Then
                Dim m As String = TextBox1.Text
                Dim confirm As Boolean = login.getconfirm(m, 1)
                If confirm = True Then
                    Chatbox.displaytext("就叫做" & My.Settings.AIName & "吧！", -2, 3)
                    ArOZInterface.Talk.Enabled = True
                    formreturncode = 0
                    Debugger.sendtodebugger(Me.Text, "FormReturn Code = " & formreturncode)
                Else
                    Chatbox.displaytext("那你想幫我改甚麼名字？", -2, 1)
                    formreturncode = 6
                    Debugger.sendtodebugger(Me.Text, "FormReturn Code = " & formreturncode)
                End If

                TextBox1.Text = Nothing
            ElseIf formreturncode = 0 Then
                Dim interfaceh As New InterfaceHandler
                interfaceh.setinterface(1, False)
                Me.Close()

            End If
            TextBox1.Text = Nothing
        End If


    End Sub


    Private Sub TextBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.Enter

    End Sub

    Private Sub TextBox1_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.Leave

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

    End Sub

    Public Sub getspecialreturn(ByVal returncode As Integer)
        formreturncode = returncode
        Debugger.sendtodebugger(Me.Text, "Return Code = " & returncode)
        Me.Show()

    End Sub

    Private Sub Linkage_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Linkage.Tick
        If link = True Then
            If formreturncode = 3 Then ' Self introduction
                Linkage.Enabled = False
                Chatbox.displaytext("我叫做 Aliz，你亦可以叫我做 艾麗絲哦！", -2, 3)
                formreturncode = 4
                Debugger.sendtodebugger(Me.Text, "FormReturn Code = " & formreturncode)
                LinkageLauncher.Enabled = True
            ElseIf formreturncode = 4 Then 'Ask if user need to change name
                Linkage.Enabled = False
                Chatbox.displaytext("我的名字好聽嗎？", -2, 2)
                link = False
                formreturncode = 5
                Debugger.sendtodebugger(Me.Text, "FormReturn Code = " & formreturncode)
                LinkageLauncher.Enabled = True
            End If
        End If

    End Sub

    Private Sub LinkageLauncher_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkageLauncher.Tick
        Linkage.Enabled = True
        LinkageLauncher.Enabled = False
    End Sub
End Class