﻿Imports System.Media

Public Class Launch
    Dim apppath As String = Application.StartupPath
    Private Sub Launch_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim x As Integer
        Dim y As Integer
        x = Screen.PrimaryScreen.WorkingArea.Width
        y = Screen.PrimaryScreen.WorkingArea.Height - Me.Height

        Do Until x = Screen.PrimaryScreen.WorkingArea.Width - Me.Width - 40
            x = x - 1
            Me.Location = New Point(x, y)
        Loop



        Timer1.Enabled = True
        Dim sndPing As New SoundPlayer(My.Resources.launch)
        sndPing.Play()
        If My.Computer.FileSystem.DirectoryExists(apppath & "\database") = False Then
            Try
                My.Computer.FileSystem.CreateDirectory(apppath & "\database")
                My.Computer.FileSystem.CreateDirectory(apppath & "\database\Basics")
                My.Computer.FileSystem.CreateDirectory(apppath & "\database\Plugins")
            Catch ex As Exception
                Dim msg As New ArOZ.ArOZUnknownMessageHandler
                Chatbox.displaytext(msg.geterrormsg(2), -2, 1)
            End Try

        End If
        If My.Computer.FileSystem.DirectoryExists(apppath & "\ghost") = False Then
            ' Just write these interface files to the base system
            Try
                My.Computer.FileSystem.CreateDirectory(apppath & "\ghost")
                My.Computer.FileSystem.CreateDirectory(apppath & "\ghost\Aliz")
                My.Resources.Aliz1.Save(apppath & "\ghost\Aliz\1.png", Drawing.Imaging.ImageFormat.Png)
                My.Resources.Aliz2.Save(apppath & "\ghost\Aliz\2.png", Drawing.Imaging.ImageFormat.Png)
                My.Resources.Aliz1_c.Save(apppath & "\ghost\Aliz\1_c.png", Drawing.Imaging.ImageFormat.Png)
                My.Resources.Aliz2_c.Save(apppath & "\ghost\Aliz\2_c.png", Drawing.Imaging.ImageFormat.Png)
                My.Resources.Aliz3.Save(apppath & "\ghost\Aliz\3.png", Drawing.Imaging.ImageFormat.Png)
            Catch ex As Exception
                Dim msg As New ArOZ.ArOZUnknownMessageHandler
                Chatbox.displaytext(msg.geterrormsg(2), -2, 1)
            End Try

        End If

        If My.Computer.FileSystem.FileExists(apppath & "/ArOZLoginTaskHandler.dll") = False Then
            ' My.Computer.FileSystem.WriteAllBytes(apppath & "/", My.Resources.ArOZLoginTaskHandler, False)
        End If
        If My.Computer.FileSystem.FileExists(apppath & "/ArOZTimeHandler.dll") = False Then
            ' My.Computer.FileSystem.WriteAllBytes(apppath & "/", My.Resources.ArOZTimeHandler, False)
        End If
        If My.Computer.FileSystem.FileExists(apppath & "/ArOZUnkownMessageHandler.dll") = False Then
            ' My.Computer.FileSystem.WriteAllBytes(apppath & "/", My.Resources.ArOZUnkownMessageHandler, False)
        End If
        If My.Computer.FileSystem.FileExists(apppath & "/ArOZFileHandler.dll") = False Then
            'My.Computer.FileSystem.WriteAllBytes(apppath & "/", My.Resources.ArOZFileHandler, False)
        End If

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Timer1.Enabled = False
        Me.Hide()
        ArOZInterface.Show()
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Label1.Text = "啟動中…"
        Timer2.Enabled = False
    End Sub

    Private Sub Timer3_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer3.Tick
        Label1.Text = "啟動錯誤"
    End Sub
End Class