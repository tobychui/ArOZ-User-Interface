﻿Public Class InterfaceHandler
    Public Sub setinterface(ByVal interfacenumber As Integer, ByVal Eyeblink As Boolean)
        On Error Resume Next
        Dim apppath As String = Application.StartupPath

        IO.File.WriteAllText((apppath & "\ghost\interface.dat"), interfacenumber, System.Text.Encoding.GetEncoding(950))
        Dim ghostlocation As String
        If My.Settings.GhostLocation <> "/default/" Then
            ghostlocation = My.Settings.GhostLocation
        Else
            ghostlocation = Application.StartupPath & "\ghost\Aliz"
        End If
        ' If ghostlocation.LastIndexOf("\") = ghostlocation.Length - 1 Then
        'ghostlocation = ghostlocation.Replace("\", "")
        ' End If


        If Eyeblink = False Then
            ArOZInterface.PictureBox1.BackgroundImage = Image.FromFile(ghostlocation & "\" & interfacenumber & ".png")
            IO.File.WriteAllText((apppath & "\ghost\interface.dat"), interfacenumber, System.Text.Encoding.GetEncoding(950))
        Else
            ArOZInterface.PictureBox1.BackgroundImage = Image.FromFile(ghostlocation & "\" & interfacenumber & "_c.png")
            IO.File.WriteAllText((apppath & "\ghost\interface.dat"), interfacenumber & "_c", System.Text.Encoding.GetEncoding(950))
        End If

    End Sub

    Public Function getinterface()
        Dim apppath As String = Application.StartupPath
        Dim interfacevalue As String
        interfacevalue = My.Computer.FileSystem.ReadAllText(apppath & "\ghost\interface.dat").ToString
        Return interfacevalue
    End Function


End Class
