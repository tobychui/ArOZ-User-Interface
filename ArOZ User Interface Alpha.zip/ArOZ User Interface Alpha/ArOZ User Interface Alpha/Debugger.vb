﻿Public Class Debugger

    Private Sub Debugger_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ListBox1.Items.Add("除錯器已經開啟")

    End Sub

    Public Sub sendtodebugger(ByVal comefrom As String, ByVal data As String)
        ListBox1.Items.Add("來自 " & comefrom & " 的Debug 信息： " & data)
    End Sub

    Private Sub ListBox1_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.DoubleClick
        ListBox1.Items.Add("User Name : " & My.Settings.UserName)
        ListBox1.Items.Add("AI Name : " & My.Settings.AIName)
        ListBox1.Items.Add("Ghost Location : " & My.Settings.GhostLocation)
  

    End Sub
End Class