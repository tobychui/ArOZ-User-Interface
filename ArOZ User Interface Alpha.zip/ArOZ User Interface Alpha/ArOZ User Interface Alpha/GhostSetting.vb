﻿Public Class Setting
    Dim appPath As String = Application.StartupPath()

    Private Sub GhostSetting_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        updatealldata()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim location As String = TextBox1.Text
        If My.Computer.FileSystem.FileExists(location & "\info.txt") Then
            Dim fileReader As String
            fileReader = My.Computer.FileSystem.ReadAllText(location & "\info.txt", System.Text.Encoding.GetEncoding(950))
            TextBox2.Text = fileReader & "  >>讀取完成<<"
            My.Settings.GhostLocation = TextBox1.Text
            My.Settings.Save()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim folderDlg As New FolderBrowserDialog
        folderDlg.ShowNewFolderButton = True

        FolderBrowserDialog1.ShowNewFolderButton = False
        FolderBrowserDialog1.Description = "請選擇人格放置的資料夾。"
        If (folderDlg.ShowDialog() = DialogResult.OK) Then
            TextBox1.Text = folderDlg.SelectedPath
        End If



        If TextBox1.Text = "" Then
            TextBox1.Text = "/default/"
        End If
    End Sub


    Private Function updatealldata()
        Try
            If My.Settings.GhostLocation = "/default/" Then
                TextBox1.Text = appPath
            Else
                TextBox1.Text = My.Settings.GhostLocation
                Dim location As String = TextBox1.Text
                If My.Computer.FileSystem.FileExists(Location & "\info.txt") Then
                    Dim fileReader As String
                    fileReader = My.Computer.FileSystem.ReadAllText(Location & "\info.txt", System.Text.Encoding.GetEncoding(950))
                    TextBox2.Text = fileReader & vbNewLine & "  >>讀取完成<<"
                    My.Settings.GhostLocation = TextBox1.Text
                    My.Settings.Save()
                End If

                NumericUpDown1.Value = My.Settings.Chatboxinterval
                NumericUpDown2.Value = My.Settings.SelfTakInteval
                NumericUpDown3.Value = My.Settings.NetworkConnectionPort
                TextBox3.Text = My.Settings.NetworkConnectionIp
            End If


            Return True
        Catch ex As Exception

        End Try
        Return False
    End Function

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        My.Settings.Chatboxinterval = NumericUpDown1.Value
        If CheckBox1.Checked = True Then
            My.Settings.SelfTakInteval = 0
        Else
            My.Settings.SelfTakInteval = NumericUpDown2.Value
        End If
        My.Settings.NetworkConnectionIp = TextBox3.Text
        My.Settings.NetworkConnectionPort = NumericUpDown3.Value
        My.Settings.Save()
    End Sub


    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If MsgBox("這將會重設所有基本設定並無法回復，你確定要重設嗎？", MsgBoxStyle.OkCancel) Then
            My.Settings.AIName = Nothing
            My.Settings.GhostLocation = Nothing
            My.Settings.Save()
            MsgBox("設定已重設，現在重新啟動ArOZ系統。", MsgBoxStyle.OkOnly)
            ArOZInterface.Close()
        End If

    End Sub

End Class