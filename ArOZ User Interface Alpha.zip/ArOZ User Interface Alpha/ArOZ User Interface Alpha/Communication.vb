﻿Public Class Communication
    Dim WithEvents Client As ArOZ_Network.Client
    ' This vb file will handle all the Chating
    Dim question As Boolean = False
    Public Sub greeting()
        On Error Resume Next
        Dim welcome As String = Nothing
        Dim time As New ArOZ.ArOZTimeHandler
        Dim now As Integer = time.gethour
        If now >= 0 And now < 3 Then
            welcome = "凌晨好哦！"
        ElseIf now >= 3 And now < 7 Then
            welcome = "早晨~又是新的一天了！"
        ElseIf now >= 7 And now < 11 Then
            welcome = "上午好，"
        ElseIf now >= 11 And now < 2 Then
            welcome = "中午了，"
        ElseIf now >= 2 And now < 7 Then
            welcome = "下午好"
        ElseIf now >= 7 And now < 10 Then
            welcome = "晚上到了！"
        Else
            welcome = "深夜了…"
        End If

        Dim message As String = "歡迎回來"
        Dim lastmeetcode As Integer = time.meetinteval(My.Settings.lastmeetmin, My.Settings.lastmeethour, My.Settings.lastmeetday, My.Settings.lastmeetmonth, My.Settings.lastmeetyear)
        If lastmeetcode = 1 Then
            message = "你的 剛才就不要關掉我啊"
        ElseIf lastmeetcode = 2 Then
            message = "歡迎回來"
        ElseIf lastmeetcode = 3 Then
            'Make a error so I know when should I start writing next time
        End If





        'My.Computer.Audio.Play("", AudioPlayMode.Background)
    End Sub

    Public Sub messageimport(ByVal message As String, ByVal relationship As Integer)
        question = checkifqs(message)
        If question = True Then

        End If

    End Sub
    Private Sub sendtoChatbox()

    End Sub

    Private Function checkifqs(ByVal message As String)
        If message.Contains("嗎") Or message.Contains("?") Or message.Contains("？") Or message.Contains("是不是") Or message.Contains("系唔系") Or (message.Contains("是否") And message.Contains("?") Or message.Contains("？")) Then
            Return True
        Else
            Return False
        End If
        Return Nothing
    End Function

    Private Function qsinformation()

    End Function

    Public Sub SelfTalk()
        On Error Resume Next
        If My.Computer.FileSystem.FileExists(Application.StartupPath & "\database\Basics\chat.txt") Then
            Dim data As New DataCalculations
            Dim message As String = data.ReadFileRandom(Application.StartupPath & "\database\Basics\chat.txt")
            If message <> Nothing Then
                If message.Contains("ff&*" And "*&ff") Then
                    Dim face As Integer = 1
                    message = message.Replace("ff&*", Nothing)
                    message = message.Replace("*&ff", Nothing)
                    face = message.Substring(message.Length - 1)
                    message = message.Substring(0, message.Length - 1)
                    Chatbox.displaytext(message, -2, face)

                    Debugger.sendtodebugger("SelfTalkCalculator", "Sent Message = " & message)
                End If
            End If
        End If
    End Sub

    Public Function PeerToPeerLenChat(ByVal id As Integer, ByVal message As String)
        On Error Resume Next
        Dim TargetID As String = ""
        TargetID = id
        If message <> Nothing Then
            Client.SendData(ArOZ_Network.Client.Convert2Ascii(message.ToString), TargetID)
        End If

    End Function

    Public Function Sendmessage(ByVal type As String, ByVal message As String)
        On Error Resume Next

        If type.Contains("[msg]") Then
            message = type & message
        ElseIf type.Contains("[/c/]") Then

        ElseIf type.Contains("[/d/]") Then
            message = type & message
        ElseIf type.Contains("[/gui/]") Then

        End If
      

        Client.SendData(ArOZ_Network.Client.Convert2Ascii(message))


    End Function

    Public Function Receivedata(ByVal Data() As Byte, ByVal ID As String) Handles Client.DataReceived
        On Error Resume Next
        If ID = Nothing Then ID = ""
        Dim Msg As String = ArOZ_Network.Client.ConvertFromAscii(Data)
        If Msg.Contains("[/d/]") Then
            Returndata(Msg)

            Return Nothing
        ElseIf Msg.Contains("[/c/]") Then

        ElseIf Msg.Contains("[/gui/]") Then

        ElseIf Msg.Contains("[msg]") Then
            Return (ID & "：" & Msg & vbNewLine)
        Else
            Return "Protocal Error"
        End If

    End Function

    Public Function StartClient()
        On Error Resume Next
        Client = New ArOZ_Network.Client()
        Dim data As New DataCalculations
        Dim ID As String = data.ReadFileContain(Application.StartupPath & "\database\basics\memory.aroz", "Launchkey:")
        ID = ID.Replace("Launchkey:", "")
        If ID = Nothing Then ID = "未知連入端"
        Dim IP As String = My.Settings.NetworkConnectionIp
        Client.Connect(IP, My.Settings.NetworkConnectionPort, ID)
    End Function

    Public Sub StopClient()
        On Error Resume Next
        Client.Disconnect()
    End Sub

    Public Sub Returndata(ByVal command As String)

        If command.Contains("GetName") Then
            Sendmessage("[/d/]", My.Settings.UserName)
        ElseIf command.Contains("GetAIName") Then
            Sendmessage("[/d/]", My.Settings.AIName)
        End If




    End Sub
End Class
