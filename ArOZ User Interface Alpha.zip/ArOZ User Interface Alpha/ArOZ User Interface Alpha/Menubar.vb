﻿Imports System.Drawing.Drawing2D
Imports System.Drawing
Public Class Menubar
    Private IsFormBeingDragged As Boolean = False

    Private MouseDownX As Integer

    Private MouseDownY As Integer
    Dim moveform As Integer = 0
    Dim moveformtest As Boolean = False
    Dim z As String
    Dim x As Integer = Screen.PrimaryScreen.WorkingArea.Width
    Dim y As Integer = Screen.PrimaryScreen.WorkingArea.Height
    Dim WithEvents Client As ArOZ_Network.Client
    Dim communication As New Communication


    Public Function CommunicationForm2(ByVal content As String, ByVal relationship As Integer)


        Return Nothing
    End Function

    Private Sub Menubar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim temp As Point
        temp = ArOZInterface.ReturnPosition()
        If temp.X > x - 410 Then
            temp.X -= 250
        Else
            temp.X += 150
        End If

        temp.Y -= 500

        Me.Location = temp
        Dim path As GraphicsPath = GetRoundedRectPath(Me.ClientRectangle, 20)
        Me.Region = New Region(path)
        Dim Timehandler As New ArOZ.ArOZTimeHandler
  

    End Sub
    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseDown, Panel1.MouseDown, Button3.MouseDown, Button2.MouseDown, Button1.MouseDown, Label1.MouseDown
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = True
            MouseDownX = e.X
            MouseDownY = e.Y
        End If

    End Sub
    'Get Round Eches
    Private Function GetRoundedRectPath(ByVal Rectangle As Rectangle, ByVal r As Integer) As GraphicsPath
        Rectangle.Offset(-1, -1)
        Dim RoundRect As New Rectangle(Rectangle.Location, New Size(r - 1, r - 1))
        Dim path As New System.Drawing.Drawing2D.GraphicsPath
        path.AddArc(RoundRect, 180, 90) '左上角

        RoundRect.X = Rectangle.Right - r '右上角
        path.AddArc(RoundRect, 270, 90)

        RoundRect.Y = Rectangle.Bottom - r '右下角
        path.AddArc(RoundRect, 0, 90)

        RoundRect.X = Rectangle.Left '左下角
        path.AddArc(RoundRect, 90, 90)

        path.CloseFigure()

        Return path
    End Function


    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseUp, Panel1.MouseClick, Panel1.MouseUp, Button3.MouseUp, Button2.MouseUp, Button1.MouseUp, Label1.MouseUp



        If e.Button = MouseButtons.Left Then

            IsFormBeingDragged = False
            If moveform = 10 Then
                moveform = 0
                Chatbox.displaytext("還是我先幫你把選單視窗收起吧！", -2, 1)
                Me.Close()
            End If

            If moveformtest = True Then
                moveform += 1
                moveformtest = False
            End If

        End If

    End Sub



    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseMove, Panel1.MouseMove, Button3.MouseMove, Button2.MouseMove, Button1.MouseMove, Label1.MouseMove



        If IsFormBeingDragged Then

            Dim temp As Point = New Point()



            temp.X = Me.Location.X + (e.X - MouseDownX)

            temp.Y = Me.Location.Y + (e.Y - MouseDownY)
            Me.Location = temp

            temp = Nothing
            Timer1.Enabled = False
            Timer2.Enabled = True



            moveformtest = True

        End If

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        On Error Resume Next
        Dim data As DataCalculations
        Label3.Text = data.GetSystemTime

        Dim temp As Point
        temp = ArOZInterface.ReturnPosition()
        If temp.X > x - 410 Then
            temp.X -= 250
        Else
            temp.X += 150
        End If
        temp.Y -= 500

        Me.Location = temp



    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Timer1.Enabled = True
        Timer2.Enabled = False
    End Sub

    Private Sub Timer3_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer3.Tick
        moveform = 0
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Chatbox.Show()
        Me.Hide()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        ArOZInterface.Close()
        Launch.Close()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Setting.Show()
        Me.Hide()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Me.Close()
        Me.Hide()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Debugger.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Inputbox.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Answerbox.Show()
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        ArOZ_NetHost.Show()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click

        communication.StartClient()
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click

        communication.StopClient()
    End Sub

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class