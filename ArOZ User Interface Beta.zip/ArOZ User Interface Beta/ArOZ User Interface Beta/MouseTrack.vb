﻿Imports System.Runtime.InteropServices

Public Class MouseTrack

    Private Sub MouseTrack_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Public Sub display(ByVal form As String, ByVal x As Integer, ByVal y As Integer)
        Label2.Text = form
        TextBox1.Text = "X: " & x
        TextBox2.Text = "Y: " & y
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim pt As POINTAPI
        pt.x = -1
        pt.y = -1

        GetCursorPos(pt)

        Label4.Text = pt.x.ToString()
        Label5.Text = pt.y.ToString()


        
    End Sub
    <DllImport("User32.dll")> _
   Public Shared Function GetCursorPos(ByRef pt As POINTAPI) As Integer
    End Function

    <StructLayout(LayoutKind.Sequential)> _
    Public Structure POINTAPI
        Public x As Integer
        Public y As Integer
    End Structure

End Class