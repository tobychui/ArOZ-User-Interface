﻿Public Class Platform_Sub
    Dim fm As New FileManagent
    Private Sub Platform_Sub_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.BackgroundImage = fm.LoadBitMap("PlatformSub")

    End Sub
End Class