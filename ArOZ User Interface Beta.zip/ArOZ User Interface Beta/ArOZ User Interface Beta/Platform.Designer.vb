﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Platform
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Animator = New System.Windows.Forms.Timer(Me.components)
        Me.Fadein = New System.Windows.Forms.Timer(Me.components)
        Me.MouseCheck = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Animator
        '
        Me.Animator.Enabled = True
        Me.Animator.Interval = 500
        '
        'Fadein
        '
        Me.Fadein.Interval = 12
        '
        'MouseCheck
        '
        Me.MouseCheck.Interval = 10
        '
        'Platform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gray
        Me.ClientSize = New System.Drawing.Size(600, 115)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Platform"
        Me.Opacity = 0.75
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ArOZ次控制面版"
        Me.TopMost = True
        Me.TransparencyKey = System.Drawing.Color.Gray
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Animator As System.Windows.Forms.Timer
    Friend WithEvents Fadein As System.Windows.Forms.Timer
    Friend WithEvents MouseCheck As System.Windows.Forms.Timer
End Class
