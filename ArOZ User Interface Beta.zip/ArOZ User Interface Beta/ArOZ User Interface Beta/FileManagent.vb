﻿Imports System.Text

Public Class FileManagent
    'Universal Setting
    Dim apppath As String = Application.StartupPath
    '#####################
    Public Function CheckFileExisits(ByVal FileLocation As String)
        If My.Computer.FileSystem.FileExists(FileLocation) = True Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function CheckDirectoryExisits(ByVal Directory As String)
        If My.Computer.FileSystem.DirectoryExists(Directory) = True Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function CreateDirectory(ByVal directory As String)
        If My.Computer.FileSystem.DirectoryExists(directory) = False Then
            My.Computer.FileSystem.CreateDirectory(directory)
            Return True
        Else
            Return False
        End If
    End Function

    Public Function WriteAndCreateFile(ByVal directory As String, ByVal fill As String)
        Dim sb As New StringBuilder
        sb.Append(fill)
        If CheckFileExisits(directory) = True Then
            Try
                My.Computer.FileSystem.DeleteFile(directory)
            Catch ex As Exception
                Return False
            End Try
        End If
        Try
            IO.File.WriteAllText((directory), sb.ToString, System.Text.Encoding.GetEncoding(950))
        Catch ex As Exception
            Return False
        End Try

        Return True
    End Function


    Function ReadFileContain(ByVal Filename As String, ByVal Contain As String)
        On Error Resume Next
        Dim code As String = Nothing
        If System.IO.File.Exists(Filename) = True Then

            Dim objReader As New System.IO.StreamReader(Filename, System.Text.Encoding.GetEncoding(950))

            Do While objReader.Peek() <> -1

                code = objReader.ReadLine() & vbNewLine
                If code.Contains(Contain) Then
                    objReader.Dispose()
                    Return code
                End If
            Loop
            objReader.Dispose()
        Else

            Return Nothing
        End If
    End Function

    Function ReadFile(ByVal Filename As String)
        On Error Resume Next
        Dim code As String = Nothing
        If System.IO.File.Exists(Filename) = True Then

            Dim objReader As New System.IO.StreamReader(Filename, System.Text.Encoding.GetEncoding(950))
            Dim sb As New StringBuilder
            Do While objReader.Peek() <> -1
                code = objReader.ReadLine() & vbNewLine
                sb.AppendLine(code)
            Loop
            objReader.Dispose()
            Return sb.ToString
        Else
            Return Nothing
        End If
    End Function

    Public Function LoadBitMap(ByVal name As String)
        If name.Contains(".png") Then
            name = name.Replace(".png", Nothing)
        End If
        Dim ghostlocation As String = Application.StartupPath & My.Settings.GhostLocation & "\"
        Dim BMP As Bitmap

        If My.Computer.FileSystem.FileExists(ghostlocation & name & ".png") Then
            BMP = Image.FromFile(ghostlocation & name & ".png")
        ElseIf My.Computer.FileSystem.FileExists(ghostlocation & "\inf\" & name & ".png") Then
            BMP = Image.FromFile(ghostlocation & "\inf\" & name & ".png")
        Else
            'MsgBox(ghostlocation & name & ".png")
            BMP = My.Resources.Tr
        End If

        

        Return BMP
    End Function

    Function RandomReadArOZCode(ByVal Filename As String)
Lb1:
        On Error Resume Next
        Dim dc As New DataCalculations
        Dim rnd As String = dc.Random(1, 64) 'Limited ArOZ Code File Maxmium Command Line are 64
        Dim code As String = Nothing
        If System.IO.File.Exists(Filename) = True Then

            Dim objReader As New System.IO.StreamReader(Filename, System.Text.Encoding.GetEncoding(950))

            Do While objReader.Peek() <> -1

                code = objReader.ReadLine() & vbNewLine
                If code.Contains("[" & rnd & "]") Then
                    objReader.Dispose()
                    Return code
                End If
            Loop
            GoTo Lb1
            objReader.Dispose()
        Else

            Return Nothing
        End If
    End Function
    Function RandomReadArOZCodeInScriptFolder(ByVal Filename As String)
Lb1:
        On Error Resume Next
        Dim dc As New DataCalculations
        Dim rnd As String = dc.Random(0, 64) 'Limited ArOZ Code File Maxmium Command Line are 64
        Dim code As String = Nothing
        If System.IO.File.Exists(Application.StartupPath & "\database\script\" & Filename & ".aroz") = True Then

            Dim objReader As New System.IO.StreamReader(Application.StartupPath & "\database\script\" & Filename & ".aroz", System.Text.Encoding.GetEncoding(950))

            Do While objReader.Peek() <> -1

                code = objReader.ReadLine() & vbNewLine
                If code.Contains("[" & rnd & "]") Then
                    objReader.Dispose()
                    code = code.Replace(code.Substring(0, code.LastIndexOf("]") + 1), Nothing)
                    Return code
                End If
            Loop
            GoTo Lb1
            objReader.Dispose()
        Else

            Return Nothing
        End If
    End Function
    Function ReadArOZDataFile(ByVal Filename As String)

        On Error Resume Next
        Dim dc As New DataCalculations
        Dim code As String = Nothing
        If System.IO.File.Exists(Application.StartupPath & "\database\script\" & Filename & ".adf") = True Then
            Dim objReader As New System.IO.StreamReader(Application.StartupPath & "\database\script\" & Filename & ".adf", System.Text.Encoding.GetEncoding(950))
            Do While objReader.Peek() <> -1

                code = objReader.ReadLine() & vbNewLine
            Loop
            objReader.Dispose()
            Return code
        Else
            Return Nothing
        End If
    End Function

    Public Sub BackupToBitmapDirectory(ByVal location As String)
        Dim ghostlocation As String = Application.StartupPath & My.Settings.GhostLocation & "\"
        Dim name As String = location.Substring(location.LastIndexOf("\"), location.Length - location.LastIndexOf("\"))
        My.Computer.FileSystem.CopyFile(location, ghostlocation & "\inf\" & name & ".png", True)
    End Sub

    Public Sub AddArOZDataFile(ByVal command As String, ByVal ScriptName As String)
        If ScriptName.Contains(".adf") Then
            ScriptName = ScriptName.Replace(".adf", Nothing)
        End If
        Dim scriptfile As String = Application.StartupPath & "\database\script\"
        If My.Computer.FileSystem.FileExists(scriptfile & ScriptName & ".adf") = False Then
            Dim sb As New StringBuilder
            sb.AppendLine(command)
            IO.File.AppendAllText((scriptfile & ScriptName & ".adf"), sb.ToString, System.Text.Encoding.GetEncoding(950))
        Else
            Dim tempmem As String = ReadFile(scriptfile & ScriptName & ".adf")
            Do Until tempmem.Substring(tempmem.Length - 1, 1) <> vbNewLine
                tempmem = tempmem.Substring(0, tempmem.Length - 1)
            Loop
            Dim sb As New StringBuilder
            ' sb.Append(tempmem)
            sb.AppendLine(command)
            'My.Computer.FileSystem.DeleteFile(scriptfile & ScriptName & ".adf", FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.DeletePermanently)
            IO.File.AppendAllText((scriptfile & ScriptName & ".adf"), sb.ToString, System.Text.Encoding.GetEncoding(950))
        End If
    End Sub
    Public Sub RemoveArOZDataFile(ByVal command As String, ByVal ScriptName As String)
        On Error Resume Next
        Dim sb As New StringBuilder
        Dim code As String = Nothing
        Dim scriptfile As String = Application.StartupPath & "\database\script\" & ScriptName & ".adf"
        If System.IO.File.Exists(scriptfile) = True Then

            Dim objReader As New System.IO.StreamReader(scriptfile, System.Text.Encoding.GetEncoding(950))

            Do While objReader.Peek() <> -1

                code = objReader.ReadLine()

                If code.Contains(command) = False Then

                    sb.AppendLine(code)
                End If
            Loop
            objReader.Dispose()
            My.Computer.FileSystem.DeleteFile(scriptfile, FileIO.UIOption.OnlyErrorDialogs, FileIO.RecycleOption.DeletePermanently)
            IO.File.AppendAllText((scriptfile), sb.ToString, System.Text.Encoding.GetEncoding(950))
        Else


        End If
    End Sub

    Function ListAllFileInDirectory(ByVal directory As String, Optional ByVal ReplaceEmpty As String = Nothing)
        On Error Resume Next
        Dim di As New IO.DirectoryInfo(directory & "\")
        Dim diar1 As IO.FileInfo() = di.GetFiles()
        Dim dra As IO.FileInfo
        Dim db As New StringBuilder
        Dim temp As String = ""
        'list the names of all files in the specified directory
        For Each dra In diar1
            If (ReplaceEmpty = Nothing) = False Then
                temp = dra.ToString.Replace(ReplaceEmpty, "")
            Else
                temp = dra.ToString
            End If
            db.AppendLine(temp.ToString)
        Next
        Return db.ToString
    End Function


End Class
