﻿Imports System.Runtime.InteropServices
Imports System
Imports System.Management

Public Class DataCalculations
    Public Function Random(ByVal start As Integer, ByVal endat As Integer)
        Dim r As New Random
        Return r.Next(start, endat)
    End Function

    Public Function MouseLocation()
        Dim pt As POINTAPI
        pt.x = -1
        pt.y = -1

        GetCursorPos(pt)

        Dim x As Integer = pt.x.ToString()
        Dim y As Integer = pt.y.ToString()

        Return x & ":" & y
    End Function
    <DllImport("User32.dll")> _
   Public Shared Function GetCursorPos(ByRef pt As POINTAPI) As Integer
    End Function

    <StructLayout(LayoutKind.Sequential)> _
    Public Structure POINTAPI
        Public x As Integer
        Public y As Integer
    End Structure

    Public Function ResizeBitmap(ByVal Souces As Bitmap, ByVal width As Integer, ByVal height As Integer)
        Dim bm_dest As New Bitmap(width, height)

        ' Make a Graphics object for the result Bitmap.
        Dim gr_dest As Graphics = Graphics.FromImage(bm_dest)

        ' Copy the source image into the destination bitmap.
        gr_dest.DrawImage(Souces, 0, 0, width, height)

        ' Display the result.
        Return bm_dest

    End Function

    Public Function BitMapExist(ByVal name As String)
        If name.Contains(".png") Then
            name = name.Replace(".png", Nothing)
        End If
        Dim ghostlocation As String = Application.StartupPath & My.Settings.GhostLocation & "\"

        If My.Computer.FileSystem.FileExists(ghostlocation & name & ".png") Then
            Return True
        ElseIf My.Computer.FileSystem.FileExists(ghostlocation & "\inf\" & name & ".png") Then
            Return True
        Else
            Return False
        End If



        Return False
    End Function

    Public Function Cmd(ByVal Command As String) As String
        Dim process As New System.Diagnostics.Process()
        process.StartInfo.FileName = "cmd.exe"
        process.StartInfo.UseShellExecute = False
        process.StartInfo.RedirectStandardInput = True
        process.StartInfo.RedirectStandardOutput = True
        process.StartInfo.RedirectStandardError = True
        process.StartInfo.CreateNoWindow = True
        process.Start()
        process.StandardInput.WriteLine(Command)
        process.StandardInput.WriteLine("exit")
        Dim Result As String = process.StandardOutput.ReadToEnd()
        process.Close()
        Return Result
    End Function

    Public Sub WaitFor(ByVal s As Integer)
        For i = 1 To s * 1000
            Application.DoEvents()
            System.Threading.Thread.Sleep(1)
        Next
    End Sub
End Class
