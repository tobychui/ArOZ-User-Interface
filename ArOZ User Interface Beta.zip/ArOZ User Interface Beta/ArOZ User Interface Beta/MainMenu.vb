﻿Imports System.Drawing.Drawing2D

Public Class MainMenu
    Dim fm As New FileManagent
    Dim dc As New DataCalculations
    Private IsFormBeingDragged As Boolean = False
    Private MouseDownX As Integer
    Private MouseDownY As Integer


    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Panel1.MouseDown
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = True
            MouseDownX = e.X
            MouseDownY = e.Y
        End If
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Panel1.MouseUp
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = False
        End If
    End Sub

    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Panel1.MouseMove
        If IsFormBeingDragged Then
            Dim temp As Point = New Point()
            temp.X = Me.Location.X + (e.X - MouseDownX)
            temp.Y = Me.Location.Y + (e.Y - MouseDownY)
            Me.Location = temp
            temp = Nothing
        End If
    End Sub
    Private Function GetRoundedRectPath(ByVal Rectangle As Rectangle, ByVal r As Integer) As GraphicsPath
        Rectangle.Offset(-1, -1)
        Dim RoundRect As New Rectangle(Rectangle.Location, New Size(r - 1, r - 1))
        Dim path As New System.Drawing.Drawing2D.GraphicsPath
        path.AddArc(RoundRect, 180, 90)     '左上角

        RoundRect.X = Rectangle.Right - r   '右上角
        path.AddArc(RoundRect, 270, 90)

        RoundRect.Y = Rectangle.Bottom - r  '右下角
        path.AddArc(RoundRect, 0, 90)

        RoundRect.X = Rectangle.Left             '左下角
        path.AddArc(RoundRect, 90, 90)

        path.CloseFigure()

        Return path
    End Function
    Private Sub Menu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Load the pictures of the suitable stuffs to suitable places
        SetStyle(ControlStyles.OptimizedDoubleBuffer, True)
        Me.SetStyle(ControlStyles.AllPaintingInWmPaint, True)

        Panel1.BackgroundImage = fm.LoadBitMap("MenuTop")
        Me.BackgroundImage = fm.LoadBitMap("MenuBG")
        'Set own location to close to the MainAction
        Me.Left = Main_Action3d.Location.X - 180
        Me.Top = Main_Action3d.Location.Y - 280
        Dim path As GraphicsPath = GetRoundedRectPath(Me.ClientRectangle, 20)
        Me.Region = New Region(path)
        For Each Con As Control In Me.Controls
            If Con.GetType Is GetType(Button) Then
                Con.BackColor = Color.Transparent
            End If
        Next
        GroupBox1.Parent = Me

    End Sub

    Private Sub Fadeout()
        Dim iCount As Integer
        For iCount = 90 To 10 Step -5
            Me.Opacity = iCount / 100
            Me.Refresh()
            Threading.Thread.Sleep(20)
        Next
        Me.Close()


    End Sub

    Private Sub Panel1_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Panel1.MouseDoubleClick
        Fadeout()

    End Sub

    Private Sub MainMenu_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        MouseTrack.display(Me.Name.ToString, e.X, e.Y)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Platform.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Fadeout()
        Launch.Close()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.Hide()
        Plugins.Show()
    End Sub

    Private Sub Button3_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Button3.MouseMove
        MouseTrack.display(Me.Name.ToString, e.X, e.Y)
    End Sub
    Public Sub ChatInputSwitch(ByVal mode As Integer)
        If mode = 0 Then
            Button1.Text = "顯示對話方塊"
        Else
            Button1.Text = "關閉對話方塊"
        End If

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Button1.Text = "顯示對話方塊" Then
            ChatInput.Show()
        Else
            ChatInput.Close()
        End If
        Me.Close()

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AutoClose.Tick
        Fadeout()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Setting.Show()
        Me.Close()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        AutoClose.Enabled = False
        ChatDisplay.ReadDialog(InputBox("Please enter the dialog you want to read", "Test Function", "HelloWorld", 100, 100))
        AutoClose.Enabled = True
    End Sub
End Class