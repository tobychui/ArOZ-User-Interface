﻿Public Class DateAndTime
    Dim fm As New FileManagent
    Dim Lastlaunch As String = Application.StartupPath & "\database\Basics\Lastlaunch.aroz"
    Public Function GetCurrentSecound()
        ' DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Return DateTime.Now.ToString("ss")
    End Function
    Public Function GetCurrentMin()
        ' DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Return DateTime.Now.ToString("mm")
    End Function
    Public Function GetCurrentHour()
        ' DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Return DateTime.Now.ToString("HH")
    End Function
    Public Function GetCurrentDate()
        ' DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Return DateTime.Now.ToString("dd")
    End Function
    Public Function GetCurrentMonth()
        ' DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Return DateTime.Now.ToString("MM")
    End Function
    Public Function GetCurrentYear()
        ' DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Return DateTime.Now.ToString("yyyy")
    End Function
    Public Function GetCurrentFullTime()
        ' DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Return DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
    End Function
    Public Function GetLastLaunchTime()

        Dim time As String = fm.ReadFile(Lastlaunch)

        Dim mm As Integer = time.Substring(14, 2)
        Dim hh As Integer = time.Substring(11, 2)
        Dim dd As Integer = time.Substring(8, 2)
        Dim mon As Integer = time.Substring(5, 2)
        Dim yr As Integer = time.Substring(0, 4)
        Dim lastload As String() = Nothing
        lastload = New String() {mm, hh, dd, mon, yr}
        Return lastload
    End Function
End Class
