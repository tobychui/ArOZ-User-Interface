﻿Imports System.Text

Public Class Setting
    Dim fm As New FileManagent
    Dim dc As New DataCalculations
    Dim Platform_Editiing As Integer = 1

    Private Sub TabPage2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage2.Click

    End Sub

    Private Sub Setting_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadPlatformSetting()
        UpdateCommandList()
    End Sub

    Private Sub LoadPlatformSetting()
        Dim Logo1 As Bitmap
        Dim Logo2 As Bitmap
        Dim logo3 As Bitmap
        Dim logo4 As Bitmap
        'Load Bitmaps from files
        Logo1 = fm.LoadBitMap(My.Settings.PlatformL1)
        Logo2 = fm.LoadBitMap(My.Settings.PlatformL2)
        logo3 = fm.LoadBitMap(My.Settings.PlatformL3)
        logo4 = fm.LoadBitMap(My.Settings.PlatfromL4)
        Logo1 = dc.ResizeBitmap(Logo1, 80, 80)
        Logo2 = dc.ResizeBitmap(Logo2, 80, 80)
        logo3 = dc.ResizeBitmap(logo3, 80, 80)
        logo4 = dc.ResizeBitmap(logo4, 80, 80)
        PictureBox1.BackgroundImage = Logo1
        PictureBox2.BackgroundImage = Logo2
        PictureBox3.BackgroundImage = logo3
        PictureBox4.BackgroundImage = logo4
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        On Error Resume Next
        Dim piclocation As String = SelectPicture.ToString
        If piclocation = Nothing Then
            Return
        End If
        Dim filename As String = piclocation.Substring(piclocation.LastIndexOf("\"), piclocation.Length - piclocation.LastIndexOf("\"))
        If dc.BitMapExist(filename) = False Then 'Check if the picture is in the ArOZ Location, if not, copy in
            fm.BackupToBitmapDirectory(piclocation)
        End If

        My.Settings.PlatformL1 = filename
        My.Settings.Save()
        LoadPlatformSetting()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        On Error Resume Next
        Dim piclocation As String = SelectPicture.ToString
        If piclocation = Nothing Then
            Return
        End If
        Dim filename As String = piclocation.Substring(piclocation.LastIndexOf("\"), piclocation.Length - piclocation.LastIndexOf("\"))
        If dc.BitMapExist(filename) = False Then 'Check if the picture is in the ArOZ Location, if not, copy in
            fm.BackupToBitmapDirectory(piclocation)
        End If

        My.Settings.PlatformL2 = filename
        My.Settings.Save()
        LoadPlatformSetting()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        On Error Resume Next
        Dim piclocation As String = SelectPicture.ToString
        If piclocation = Nothing Then
            Return
        End If
        Dim filename As String = piclocation.Substring(piclocation.LastIndexOf("\"), piclocation.Length - piclocation.LastIndexOf("\"))
        If dc.BitMapExist(filename) = False Then 'Check if the picture is in the ArOZ Location, if not, copy in
            fm.BackupToBitmapDirectory(piclocation)
        End If

        My.Settings.PlatformL3 = filename
        My.Settings.Save()
        LoadPlatformSetting()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        On Error Resume Next
        Dim piclocation As String = SelectPicture.ToString
        If piclocation = Nothing Then
            Return
        End If
        Dim filename As String = piclocation.Substring(piclocation.LastIndexOf("\"), piclocation.Length - piclocation.LastIndexOf("\"))
        If dc.BitMapExist(filename) = False Then 'Check if the picture is in the ArOZ Location, if not, copy in
            fm.BackupToBitmapDirectory(piclocation)
        End If

        My.Settings.PlatfromL4 = filename
        My.Settings.Save()
        LoadPlatformSetting()
    End Sub
    Private Function SelectPicture()
        Dim fd As OpenFileDialog = New OpenFileDialog()
        Dim strFileName As String = Nothing

        fd.Title = "請選擇圖片檔案"
        fd.InitialDirectory = Application.StartupPath
        fd.Filter = "Image Files (*.png)|*.png"
        fd.FilterIndex = 2
        fd.RestoreDirectory = True

        If fd.ShowDialog() = DialogResult.OK Then
            strFileName = fd.FileName
        End If
        Return strFileName
    End Function

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
      

    End Sub

    Private Sub CheckBox5_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox5.CheckedChanged
        If CheckBox5.Checked = True Then
            CheckBox6.Checked = False
            CheckBox7.Checked = False
            CheckBox8.Checked = False
            Platform_Editiing = 1
            UpdateCommandList()
        End If
    End Sub

    Private Sub CheckBox6_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox6.CheckedChanged
        If CheckBox6.Checked = True Then
            CheckBox7.Checked = False
            CheckBox8.Checked = False
            CheckBox5.Checked = False
            Platform_Editiing = 2
            UpdateCommandList()
        End If
    End Sub

    Private Sub CheckBox7_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox7.CheckedChanged
        If CheckBox7.Checked = True Then
            CheckBox8.Checked = False
            CheckBox5.Checked = False
            CheckBox6.Checked = False
            Platform_Editiing = 3
            UpdateCommandList()
        End If
    End Sub

    Private Sub CheckBox8_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox8.CheckedChanged
        If CheckBox8.Checked = True Then
            CheckBox6.Checked = False
            CheckBox7.Checked = False
            CheckBox5.Checked = False
            Platform_Editiing = 4
            UpdateCommandList()
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    End Sub

    Private Sub UpdateCommandList()
 
    End Sub

   
    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TabPage1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage1.Click

    End Sub
End Class