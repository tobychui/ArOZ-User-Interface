﻿Imports System.Drawing.Drawing2D
Imports System.Text

Public Class Plugins
    Dim fm As New FileManagent
    Private IsFormBeingDragged As Boolean = False
    Private MouseDownX As Integer
    Private MouseDownY As Integer
    Dim relx As String
    Dim pluginlib As String = Application.StartupPath & "\database\Plugins\"
    Dim rely As String
    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseDown, Panel1.MouseDown

        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = True
            MouseDownX = e.X
            MouseDownY = e.Y
        End If
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseUp, Panel1.MouseUp
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = False


            Dim newpoint As Point
            newpoint.Y = Main_Action3d.Left - Me.Left
            newpoint.X = Main_Action3d.Top - Me.Top

            My.Settings.ChatLocation = newpoint
            My.Settings.Save()
        End If
    End Sub

    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseMove, Panel1.MouseMove
        If IsFormBeingDragged Then
            Dim temp As Point = New Point()
            temp.X = Me.Location.X + (e.X - MouseDownX)
            temp.Y = Me.Location.Y + (e.Y - MouseDownY)
            Me.Location = temp
            temp = Nothing
        End If
        MouseTrack.display(Me.Name.ToString, e.X, e.Y)
    End Sub
    Private Sub Plugins_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MyBase.SetStyle(ControlStyles.UserPaint, True)
        MyBase.SetStyle(ControlStyles.OptimizedDoubleBuffer, True)
        MyBase.SetStyle(ControlStyles.SupportsTransparentBackColor, True)

        Panel1.BackgroundImage = fm.LoadBitMap("PluginTop")
        Me.BackgroundImage = fm.LoadBitMap("PluginBG")
        'Set own location to close to the MainAction

        Dim path As GraphicsPath = GetRoundedRectPath(Me.ClientRectangle, 20)
        Me.Region = New Region(path)
        For Each Con As Control In Me.Controls
            If Con.GetType Is GetType(Button) Then
                Con.BackColor = Color.Transparent
            End If
        Next

        Dim di As New IO.DirectoryInfo(pluginlib)
        ' MsgBox(pluginlib)
        Dim diar1 As IO.FileInfo() = di.GetFiles()
        Dim dra As IO.FileInfo
        Dim empty As Boolean = True
        'list the names of all files in the specified directory
        ListBox1.Items.Clear()
        For Each dra In diar1
            If dra.ToString.Contains(".exe") Then
                'MsgBox(dra.ToString)
                ListBox1.Items.Add(dra.ToString.Replace(".exe", ""))
                empty = False
            End If
        Next
        If empty = True Then
            ListBox1.Items.Add("未檢測到存在任何ArOZ插件")
        End If
    End Sub


    Private Function GetRoundedRectPath(ByVal Rectangle As Rectangle, ByVal r As Integer) As GraphicsPath
        Rectangle.Offset(-1, -1)
        Dim RoundRect As New Rectangle(Rectangle.Location, New Size(r - 1, r - 1))
        Dim path As New System.Drawing.Drawing2D.GraphicsPath
        path.AddArc(RoundRect, 180, 90)     '左上角

        RoundRect.X = Rectangle.Right - r   '右上角
        path.AddArc(RoundRect, 270, 90)

        RoundRect.Y = Rectangle.Bottom - r  '右下角
        path.AddArc(RoundRect, 0, 90)

        RoundRect.X = Rectangle.Left             '左下角
        path.AddArc(RoundRect, 90, 90)

        path.CloseFigure()

        Return path
    End Function

    Private Sub Panel1_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Panel1.MouseDoubleClick
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            Process.Start(pluginlib & ListBox1.SelectedItem & ".exe")
        Catch ex As Exception

        End Try
        Me.Hide()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

    End Sub
End Class