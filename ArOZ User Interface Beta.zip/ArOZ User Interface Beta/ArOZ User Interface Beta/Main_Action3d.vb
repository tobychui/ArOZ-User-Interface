﻿Imports System.ComponentModel

Public Class Main_Action3d
    'Imports Functions
    Dim dc As New DataCalculations
    Dim dt As New DateAndTime
    Dim fm As New FileManagent
    Dim bw As BackgroundWorker = New BackgroundWorker
    'Program moving details
    Private IsFormBeingDragged As Boolean = False
    Private MouseDownX As Integer
    Private MouseDownY As Integer
    Dim interfacecode As Integer = 4
    'eyes Details 
    Dim eyeclosed As Boolean = False
    Dim eyeframe As Point
    Dim eyelocation As Point

    'Refrence data
    Dim mid_point As Point

    Dim apppath As String = Application.StartupPath
    Dim basics As String = apppath & "\database\basics\"
    Dim screenWidth As Integer = Screen.PrimaryScreen.Bounds.Width
    Dim screenHeight As Integer = Screen.PrimaryScreen.Bounds.Height


    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Main.MouseDown
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = True
            MouseDownX = e.X
            MouseDownY = e.Y
        End If
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Main.MouseUp
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = False
        End If
    End Sub

    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Main.MouseMove
        If IsFormBeingDragged Then
            Dim temp As Point = New Point()
            temp.X = Me.Location.X + (e.X - MouseDownX)
            temp.Y = Me.Location.Y + (e.Y - MouseDownY)
            Me.Location = temp
            temp = Nothing
        End If
        MouseTrack.display(Me.Name.ToString, e.X, e.Y)
    End Sub

    Private Sub Main_Action3d_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'ArOZ will autometic go to the suitable place on the screen, by default, right down
        '** Defaut Setting Stuffs
        eyelocation.X = 0
        eyelocation.Y = 0
        Eye_Blink_Tick(Nothing, Nothing)
        MouseTrack.Show()
        Me.Left = screenWidth / 100 * 80
        Me.Top = screenHeight - 268
        Me.TopMost = True
        mid_point.X = Main.Width / 2
        mid_point.Y = Main.Height / 2
        SetStyle(ControlStyles.OptimizedDoubleBuffer, True)
        Me.SetStyle(ControlStyles.AllPaintingInWmPaint, True)
        '**** End of Setting
        'Try to load user name and other data, if no, ask for them
        Dim fm As New FileManagent
        Dim username As String = fm.ReadArOZDataFile("username")
        If username = Nothing Then
            Dim ci As New ChatInput
            dc.WaitFor(3)
            ChatDisplay.DisplayMessage("你…能告訴我…你的名字嗎？", 2)
            fm.AddArOZDataFile(ci.GetReturn, "username")
            username = fm.ReadArOZDataFile("username")
            ChatDisplay.DisplayMessage("第一次見面，你好哦！" & username.Replace(vbNewLine, "") & "。")
            GoTo endhere
        End If
        ChatDisplay.Label1.Text = ChatDisplay.Label1.Text & username.Replace(vbNewLine, "") & "。"
        '**** Display Welcome text loaded by Launch form
        '2015年補充：ChatDisply 中的字是由 Launch 直接指派 =w=（幹！那時候幹麼寫得這麼複雜）
        ChatDisplay.Show()
endhere:
    End Sub

    Private Sub Eye_Blink_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Eye_Blink.Tick
        'Close her eyes

        Eye_open.Interval = dc.Random(100, 250) * 5

        Dim bg As Bitmap
        'bg = Image.FromFile(apppath & My.Settings.GhostLocation & "\" & interfacecode & ".png")
        bg = fm.LoadBitMap(interfacecode)
        bg = ResizeBitmap(bg)

        Dim l1 As Bitmap
        'l1 = Image.FromFile(apppath & My.Settings.GhostLocation & "\" & interfacecode & "ec.png")
        l1 = fm.LoadBitMap(interfacecode & "ec")
        l1 = ResizeBitmap(l1)


        refreshimage(bg, l1, 0, 0)
        eyeclosed = True
        Eye_open.Enabled = True
        Eye_Blink.Enabled = False
    End Sub

    Private Sub Eye_open_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Eye_open.Tick
        'Open her eyes

        Eye_Blink.Interval = dc.Random(100, 250) * 15
        Dim bg As Bitmap
        'bg = Image.FromFile(apppath & My.Settings.GhostLocation & "\" & interfacecode & ".png")
        bg = fm.LoadBitMap(interfacecode)
        bg = ResizeBitmap(bg)

        Dim l1 As Bitmap
        'l1 = Image.FromFile(apppath & My.Settings.GhostLocation & "\" & interfacecode & "eb.png")
        l1 = fm.LoadBitMap(interfacecode & "eb")
        l1 = ResizeBitmap(l1)
        refreshimage(bg, l1, eyelocation.X, eyelocation.Y)
        eyeclosed = False
        Eye_open.Enabled = False
        Eye_Blink.Enabled = True
    End Sub
    Private Sub refreshimage(ByVal background As Bitmap, ByVal layer1 As Bitmap, ByVal l1x As Integer, ByVal l1y As Integer)
        Dim BMP As New Bitmap(200, 271)

        'create a graphic base on that
        Dim GR As Graphics = Graphics.FromImage(BMP)

        'draw onto your bmp starting from the background
        GR.DrawImage(My.Resources.Tr, 0, 0)

        'set X,y to the coordinate you want your girl to appear
        GR.DrawImage(background, 0, 0)
        GR.DrawImage(layer1, l1x, l1y)
        'clear the picturebox
        Main.Image = Nothing

        'now that we have draw all our image onto the same bitmap, assign it to your picturebox element
        Main.BackgroundImage = ResizeBitmap(BMP)
        Main.Refresh()
    End Sub

    Function ResizeBitmap(ByVal bitmapToResize As Bitmap)
        Dim bm_dest As New Bitmap(200, 271)

        ' Make a Graphics object for the result Bitmap.
        Dim gr_dest As Graphics = Graphics.FromImage(bm_dest)

        ' Copy the source image into the destination bitmap.
        gr_dest.DrawImage(bitmapToResize, 0, 0, 200, 271)

        ' Display the result.
        Return bm_dest
    End Function



    Private Sub Eye_Move_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Eye_Move.Tick

        If eyeclosed = False Then
            'Handle X axis movement
            If MouseTrack.Label4.Text < Me.Left + 75 Then
                If eyelocation.X > -5 Then
                    eyelocation.X -= 1
                Else
                    eyelocation.X = -5
                End If

            ElseIf MouseTrack.Label4.Text > Me.Left + 125 Then

                If eyelocation.X < 5 Then
                    eyelocation.X += 1
                Else
                    eyelocation.X = 5
                End If
            Else
                If eyelocation.X < 0 Then
                    eyelocation.X += 1
                ElseIf eyelocation.X > 0 Then
                    eyelocation.X -= 1
                End If
            End If

            'Handle y axis movement
            If MouseTrack.Label5.Text < Me.Top + 40 Then
                If eyelocation.Y > -2 Then
                    eyelocation.Y -= 1
                Else
                    eyelocation.Y = -2
                End If

            ElseIf MouseTrack.Label5.Text > Me.Top + 140 Then
                If eyelocation.Y < 1 Then
                    eyelocation.Y += 1
                Else
                    eyelocation.Y = 1
                End If


            Else
                If eyelocation.Y < 0 Then
                    eyelocation.Y += 1
                ElseIf eyelocation.Y > 0 Then
                    eyelocation.Y -= 1
                End If
            End If
        End If

        Dim bg As Bitmap
        'bg = Image.FromFile(apppath & My.Settings.GhostLocation & "\" & interfacecode & ".png")
        bg = fm.LoadBitMap(interfacecode)
        bg = ResizeBitmap(bg)

        Dim l1 As Bitmap
        'l1 = Image.FromFile(apppath & My.Settings.GhostLocation & "\" & interfacecode & "eb.png")
        l1 = fm.LoadBitMap(interfacecode & "eb")
        l1 = ResizeBitmap(l1)
        refreshimage(bg, l1, eyelocation.X, eyelocation.Y)
    End Sub


    Private Sub Main_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Main.MouseClick
        If e.Button = Windows.Forms.MouseButtons.Right Then
            'Show Main Menu when user click on her
            MainMenu.Show()
        ElseIf e.Button = Windows.Forms.MouseButtons.Left Then
            ChatDisplay.Show()
        End If
    End Sub

    Private Sub Main_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Main.Click

    End Sub
    Public Sub SetInterfaceCode(ByVal code As Integer)
        interfacecode = code
    End Sub

    Private Sub LoadResponces_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles LoadResponces.DoWork
        Dim worker As BackgroundWorker = CType(sender, BackgroundWorker)
        ReadLoginTimeSlot()
    End Sub
    Private Function ReadLoginTimeSlot()
        Dim ll As String = fm.ReadFile(basics & "Lastlaunch.aroz")
        If ll = Nothing Then
            GoTo endhere
        Else
            Dim lastlaunch As String() = dt.GetLastLaunchTime()
            If dt.GetCurrentYear = lastlaunch(4) Then
                If dt.GetCurrentMonth = lastlaunch(3) Then
                    If dt.GetCurrentDate = lastlaunch(2) Then
                        If dt.GetCurrentHour = lastlaunch(1) Then
                            If dt.GetCurrentMin = lastlaunch(0) Then

                            Else
                                'Come back within a min =w=
                            End If
                        Else
                            'Come back within an hour
                        End If
                    Else
                        'Come back after a day or more
                    End If
                Else
                    'Come back after more than 1 month
                End If
            Else
                'Come back after more than a year
            End If
        End If

        Return False
endhere:
        Return Nothing
    End Function

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Welcomespeech.Tick
        ReadLoginTimeSlot()
    End Sub
End Class
