﻿Public Class Platform
    Dim dc As New DataCalculations
    Dim fm As New FileManagent
    Dim Sub_Opa As Double = 0
    Private Sub Platform_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Reduce Fliking
        SetStyle(ControlStyles.OptimizedDoubleBuffer, True)
        Me.SetStyle(ControlStyles.AllPaintingInWmPaint, True)

        Me.Opacity = 0

        Fadein.Enabled = True

    End Sub



    Private Sub Animator_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Animator.Tick
        Animator.Enabled = False

        Dim Logo1 As Bitmap
        Dim Logo2 As Bitmap
        Dim logo3 As Bitmap
        Dim logo4 As Bitmap
        'Load Bitmaps from files
        Logo1 = fm.LoadBitMap(My.Settings.PlatformL1)
        Logo2 = fm.LoadBitMap(My.Settings.PlatformL2)
        logo3 = fm.LoadBitMap(My.Settings.PlatformL3)
        logo4 = fm.LoadBitMap(My.Settings.PlatfromL4)
        'Resize all bitmaps
        Logo1 = dc.ResizeBitmap(Logo1, 95, 95)
        Logo2 = dc.ResizeBitmap(Logo2, 95, 95)
        logo3 = dc.ResizeBitmap(logo3, 95, 95)
        logo4 = dc.ResizeBitmap(logo4, 95, 95)

        For i = 1 To 50
            Dim BMP As New Bitmap(780, 160)
            'create a graphic base on that
            Dim GR As Graphics = Graphics.FromImage(BMP)
            'draw onto your bmp starting from the background
            GR.DrawImage(dc.ResizeBitmap(My.Resources.PlatformBG, 600, 115), 0, 0)

            GR.DrawImage(Logo1, 100, 10)
            GR.DrawImage(Logo2, i * 2 + 100, 10)
            GR.DrawImage(logo3, 2 * i * 2 + 100, 10)
            GR.DrawImage(logo4, 3 * i * 2 + 100, 10)
            'clear the picturebox

            Me.BackgroundImage = BMP
            'now that we have draw all our image onto the same bitmap, assign it to your picturebox element
            Application.DoEvents()
        Next
    End Sub

    Private Sub Platform_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
        MouseTrack.display(Me.Name.ToString, e.X, e.Y)
        If e.X < 100 Or e.X > 500 Or e.Y < 10 Or e.Y > 105 Then
            MouseCheck.Enabled = False
            Platform_Sub.Hide()
        End If
        If e.X > 100 And e.X < 500 And e.Y > 10 And e.Y < 105 Then
            Platform_Sub.Left = e.X
            Platform_Sub.Top = e.Y + 100
            Platform_Sub.Show()
            MouseCheck.Enabled = True
        End If
    End Sub

    Private Sub Platform_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseClick

        If e.Location.X < 593 And e.Location.X > 576 And e.Location.Y > 45 And e.Location.Y < 65 Then
            Dim Logo1 As Bitmap
            Dim Logo2 As Bitmap
            Dim logo3 As Bitmap
            Dim logo4 As Bitmap
            'Load Bitmaps from files
            Logo1 = fm.LoadBitMap(My.Settings.PlatformL1)
            Logo2 = fm.LoadBitMap(My.Settings.PlatformL2)
            logo3 = fm.LoadBitMap(My.Settings.PlatformL3)
            logo4 = fm.LoadBitMap(My.Settings.PlatfromL4)
            'Resize all bitmaps
            Logo1 = dc.ResizeBitmap(Logo1, 95, 95)
            Logo2 = dc.ResizeBitmap(Logo2, 95, 95)
            logo3 = dc.ResizeBitmap(logo3, 95, 95)
            logo4 = dc.ResizeBitmap(logo4, 95, 95)

            For i = 1 To 50
                Dim BMP As New Bitmap(780, 160)
                'create a graphic base on that
                Dim GR As Graphics = Graphics.FromImage(BMP)
                'draw onto your bmp starting from the background
                GR.DrawImage(dc.ResizeBitmap(My.Resources.PlatformBG, 600, 115), 0, 0)

                GR.DrawImage(Logo1, 100, 10)
                GR.DrawImage(Logo2, 200 - i * 2, 10)
                GR.DrawImage(logo3, 300 - i * 4, 10)
                GR.DrawImage(logo4, 400 - i * 6, 10)
                'clear the picturebox

                Me.BackgroundImage = BMP
                'now that we have draw all our image onto the same bitmap, assign it to your picturebox element
                Application.DoEvents()
            Next
            Dim iCount As Integer
            For iCount = 90 To 10 Step -5
                Me.Opacity = iCount / 100
                Me.Refresh()
                Threading.Thread.Sleep(25)
            Next
            Me.Close()
        End If
    End Sub

    Private Sub Fadein_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Fadein.Tick
        Me.Opacity += 0.01
        Sub_Opa += 0.01
        If Sub_Opa > 0.75 Then
            Fadein.Enabled = False
            Me.Opacity = 0.75
        End If
    End Sub

    Private Sub MouseCheck_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MouseCheck.Tick
    End Sub
End Class