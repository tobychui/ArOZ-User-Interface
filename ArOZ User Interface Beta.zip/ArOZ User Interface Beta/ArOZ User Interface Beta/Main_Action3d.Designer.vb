﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main_Action3d
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main_Action3d))
        Me.Main = New System.Windows.Forms.PictureBox
        Me.Eye_Blink = New System.Windows.Forms.Timer(Me.components)
        Me.Eye_open = New System.Windows.Forms.Timer(Me.components)
        Me.Eye_Move = New System.Windows.Forms.Timer(Me.components)
        Me.LoadResponces = New System.ComponentModel.BackgroundWorker
        Me.Welcomespeech = New System.Windows.Forms.Timer(Me.components)
        CType(Me.Main, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Main
        '
        Me.Main.BackColor = System.Drawing.Color.Black
        Me.Main.BackgroundImage = CType(resources.GetObject("Main.BackgroundImage"), System.Drawing.Image)
        Me.Main.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Main.Location = New System.Drawing.Point(0, 1)
        Me.Main.Name = "Main"
        Me.Main.Size = New System.Drawing.Size(200, 271)
        Me.Main.TabIndex = 0
        Me.Main.TabStop = False
        '
        'Eye_Blink
        '
        Me.Eye_Blink.Enabled = True
        Me.Eye_Blink.Interval = 1500
        '
        'Eye_open
        '
        '
        'Eye_Move
        '
        Me.Eye_Move.Enabled = True
        Me.Eye_Move.Interval = 60
        '
        'LoadResponces
        '
        '
        'Welcomespeech
        '
        Me.Welcomespeech.Enabled = True
        Me.Welcomespeech.Interval = 4000
        '
        'Main_Action3d
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(200, 304)
        Me.Controls.Add(Me.Main)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Main_Action3d"
        Me.Text = "ArOZ"
        Me.TransparencyKey = System.Drawing.Color.Black
        CType(Me.Main, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Main As System.Windows.Forms.PictureBox
    Friend WithEvents Eye_Blink As System.Windows.Forms.Timer
    Friend WithEvents Eye_open As System.Windows.Forms.Timer
    Friend WithEvents Eye_Move As System.Windows.Forms.Timer
    Friend WithEvents LoadResponces As System.ComponentModel.BackgroundWorker
    Friend WithEvents Welcomespeech As System.Windows.Forms.Timer

End Class
