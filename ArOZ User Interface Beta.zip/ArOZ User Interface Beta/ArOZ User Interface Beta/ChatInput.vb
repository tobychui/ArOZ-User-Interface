﻿Public Class ChatInput
    Dim fm As New FileManagent
    Dim dc As New DataCalculations
    Private IsFormBeingDragged As Boolean = False
    Private MouseDownX As Integer
    Private MouseDownY As Integer
    Dim relx As String
    Dim rely As String
    Dim enterpressed As Boolean = False
    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseDown

        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = True
            MouseDownX = e.X
            MouseDownY = e.Y
            Updates.Enabled = False
        End If
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseUp
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = False


            Dim newpoint As Point
            newpoint.Y = Main_Action3d.Left - Me.Left
            newpoint.X = Main_Action3d.Top - Me.Top

            My.Settings.ChatLocation = newpoint
            My.Settings.Save()
            Updates.Enabled = True
        End If
    End Sub

    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseMove
        If IsFormBeingDragged Then
            Dim temp As Point = New Point()
            temp.X = Me.Location.X + (e.X - MouseDownX)
            temp.Y = Me.Location.Y + (e.Y - MouseDownY)
            Me.Location = temp
            temp = Nothing
        End If
        MouseTrack.display(Me.Name.ToString, e.X, e.Y)
    End Sub

    Private Sub ChatInput_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Setting background and location

        Me.BackgroundImage = fm.LoadBitMap("InputDisplayBG")
        Me.Top = Main_Action3d.Top - 80
        Me.Left = Main_Action3d.Left - 340
        TextBox1.Parent = Me
        'Count down to autoshut
        MainMenu.ChatInputSwitch(1)
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Updates_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Updates.Tick
        relx = My.Settings.ChatLocation.X
        rely = My.Settings.ChatLocation.Y
        Me.Top = Main_Action3d.Top - relx
        Me.Left = Main_Action3d.Left - rely
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Microsoft.VisualBasic.ChrW(Keys.Enter) Then
            enterpressed = True
            Me.Hide()
        End If
    End Sub

    Public Function GetReturn()
        Me.Show()
        Do Until enterpressed = True
            dc.WaitFor(5)
            Application.DoEvents()
        Loop
        Return TextBox1.Text
    End Function
End Class