﻿Public Class FaceExpressionHandler
    Dim fm As New FileManagent
    Dim dc As New DataCalculations
    Dim apppdata As String = Application.StartupPath
    Dim tagfile As String = Application.StartupPath & My.Settings.GhostLocation & "\tag"

    Public Sub TagToExpression(ByVal TagString As String,expressioncode As Integer)
        Dim temp As String = fm.ReadFile(tagfile & "\" & expressioncode & ".tag")
        My.Computer.FileSystem.DeleteFile(tagfile & "\" & expressioncode & ".tag")
        fm.WriteAndCreateFile(tagfile & "\" & expressioncode & ".tag", temp & TagString & vbNewLine)
    End Sub

    Public Sub RemoveTag(ByVal TagString As String, ByVal expressioncode As Integer)
        Dim temp As String = fm.ReadFile(tagfile & "\" & expressioncode & ".tag")
        temp = temp.Replace(TagString & vbNewLine, Nothing)
        fm.WriteAndCreateFile(tagfile & "\" & expressioncode & ".tag", temp)
    End Sub
    Public Function SearchExpressionFromTag(ByVal TagString As String)
        Dim expressioncode As Integer = 0
        For i = 1 To 100
            If My.Computer.FileSystem.FileExists(tagfile & "\" & i & ".tag") = True Then
                Dim temp As String = fm.ReadFile(tagfile & "\" & i & ".tag")
                If temp.Contains(TagString) Then
                    Return i
                End If
            End If

        Next
        Return Expressioncode
    End Function
    Public Function ListTagFromExpression(ByVal ExpressionCode As Integer)
        Dim tagstring As String = fm.ReadFile(tagfile & "\" & ExpressionCode & ".tag")
        Return tagstring
    End Function
    Public Function ReturnInterfaceCode(ByVal Words As String)
        Dim code As Integer = 4

        Return code
    End Function
End Class
