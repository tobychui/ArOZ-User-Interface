﻿Imports System.Drawing.Drawing2D
Imports System.Text

Public Class Launch
    Dim apppath As String = Application.StartupPath
    Dim fm As New FileManagent
    Dim File As New FileManagent
    'The Folowing down there control the the location of the launch screen
    Private IsFormBeingDragged As Boolean = False
    Private MouseDownX As Integer
    Private MouseDownY As Integer


    Private Sub Form1_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseDown, Label1.MouseDown
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = True
            MouseDownX = e.X
            MouseDownY = e.Y
        End If
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseUp, Label1.MouseUp
        If e.Button = MouseButtons.Left Then
            IsFormBeingDragged = False
        End If
    End Sub

    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseMove, Label1.MouseMove
        If IsFormBeingDragged Then
            Dim temp As Point = New Point()
            temp.X = Me.Location.X + (e.X - MouseDownX)
            temp.Y = Me.Location.Y + (e.Y - MouseDownY)
            Me.Location = temp
            temp = Nothing
        End If
    End Sub
    Private Function GetRoundedRectPath(ByVal Rectangle As Rectangle, ByVal r As Integer) As GraphicsPath
        Rectangle.Offset(-1, -1)
        Dim RoundRect As New Rectangle(Rectangle.Location, New Size(r - 1, r - 1))
        Dim path As New System.Drawing.Drawing2D.GraphicsPath
        path.AddArc(RoundRect, 180, 90)     '左上角

        RoundRect.X = Rectangle.Right - r   '右上角
        path.AddArc(RoundRect, 270, 90)

        RoundRect.Y = Rectangle.Bottom - r  '右下角
        path.AddArc(RoundRect, 0, 90)

        RoundRect.X = Rectangle.Left             '左下角
        path.AddArc(RoundRect, 90, 90)

        path.CloseFigure()

        Return path
    End Function

    Private Sub Launch_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '****Display Welcome Text
        Dim words As String = fm.RandomReadArOZCodeInScriptFolder("startup")
        ChatDisplay.Label1.Text = words
        Dim timedate As New DateAndTime
        Dim time As Integer = timedate.GetCurrentHour

        If time < 10 And time > 0 Then
            Label2.Text = "早上好！" & My.Settings.UserName
        ElseIf time >= 10 And time < 15 Then
            Label2.Text = "中午好！" & My.Settings.UserName
        ElseIf time >= 15 And time < 19 Then
            Label2.Text = "下午好！" & My.Settings.UserName
        Else
            Label2.Text = "晚上好！" & My.Settings.UserName
        End If
        My.Computer.Audio.Play(My.Resources.ArOZ_launch, AudioPlayMode.Background)
        Timer1.Enabled = True
        Dim path As GraphicsPath = GetRoundedRectPath(Me.ClientRectangle, 20)
        Me.Region = New Region(path)
        CheckFirstLog()
        Me.Refresh()


    End Sub

    Private Sub AddTextToDisplace(ByVal text As String)

        Label1.Text = Label1.Text & vbNewLine & text
    End Sub

    Private Sub CheckFirstLog()
        Dim datetime As New DateAndTime
        If File.CheckDirectoryExisits(apppath & "\database\") Then
            AddTextToDisplace("正在載入DataBase目錄…")
            Application.DoEvents()
        Else
            AddTextToDisplace("正在創建新資料庫檔案…")
            File.CreateDirectory(apppath & "\database\")
            Application.DoEvents()
            AddTextToDisplace("正在創建新基本插件資料庫檔案…")
            File.CreateDirectory(apppath & "\database\Plugins")
            Application.DoEvents()
            AddTextToDisplace("正在創建新基本認知庫檔案…")
            File.CreateDirectory(apppath & "\database\Basics")
            Application.DoEvents()
        End If
        AddTextToDisplace("完成載入DataBase目錄。")
        Application.DoEvents()
        Dim basics As String = apppath & "\database\Basics"
        If My.Computer.FileSystem.DirectoryExists(apppath & "\database\Basics\srq") = False Then
            My.Computer.FileSystem.CreateDirectory(basics & "\srq")
        End If
        If My.Computer.FileSystem.DirectoryExists(apppath & "\database\Basics\rrq") = False Then
            My.Computer.FileSystem.CreateDirectory(basics & "\rrq")
        End If
        If My.Computer.FileSystem.DirectoryExists(apppath & "\database\Basics\airq") = False Then
            My.Computer.FileSystem.CreateDirectory(basics & "\airq")
        End If
        AddTextToDisplace("對話反應檔載入完成。")
        If File.CheckFileExisits(apppath & "\database\Basics\fimg.aroz") = False Then
            AddTextToDisplace("正在建立印象記憶檔…")
            Application.DoEvents()
            Dim sb As New StringBuilder
            sb.AppendLine("First_Launch_Date=" & datetime.GetCurrentDate.ToString)
            sb.AppendLine("First_Launch_Month=" & datetime.GetCurrentMonth)
            sb.AppendLine("First_Launch_Year=" & datetime.GetCurrentYear)
            sb.AppendLine("First_Launch_Second=" & datetime.GetCurrentSecound)
            sb.AppendLine("First_Launch_Min=" & datetime.GetCurrentMin)
            sb.AppendLine("First_Launch_Hour=" & datetime.GetCurrentHour)
            File.WriteAndCreateFile(apppath & "\database\Basics\fimg.aroz", sb.ToString)
            AddTextToDisplace("印象記憶記錄完成。")
            Application.DoEvents()
        Else
            AddTextToDisplace("印象記憶記讀取完成。")
            Application.DoEvents()
            Threading.Thread.Sleep(5)
        End If
        AddTextToDisplace("正在建立啟動記錄檔…")
        Application.DoEvents()
        Threading.Thread.Sleep(5)
        File.WriteAndCreateFile(apppath & "\database\Basics\Lastlaunch.aroz", datetime.GetCurrentFullTime)

        If File.CheckDirectoryExisits(apppath & "\ghost\") = False Then
            File.CreateDirectory(apppath & "\ghost\")
            AddTextToDisplace("建立Ghost人格完成。")
            Application.DoEvents()
            Threading.Thread.Sleep(5)
        End If
        If File.CheckDirectoryExisits(apppath & "\database\script\") = False Then
            File.CreateDirectory(apppath & "\database\script\")
            AddTextToDisplace("建立adf資料庫完成。")
            Application.DoEvents()
            Threading.Thread.Sleep(5)
        End If
        If File.CheckDirectoryExisits(apppath & "\database\script\dialog\") = False Then
            File.CreateDirectory(apppath & "\database\script\dialog\")
            AddTextToDisplace("建立對話資料庫完成。")
            Application.DoEvents()
            Threading.Thread.Sleep(5)
        End If

        AddTextToDisplace("程式初始化中…")
        Application.DoEvents()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Me.Hide()
        Main_Action3d.Show()
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Label2.ForeColor = Color.Pink Then
            Label2.ForeColor = Color.White
        Else
            Label2.ForeColor = Color.Pink
        End If
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class