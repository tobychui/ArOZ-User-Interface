﻿Public Class CommunicationHandler
    Dim apppath As String = Application.StartupPath
    Dim fm As New FileManagent
    Dim dc As New DataCalculations
    Dim Basics As String = apppath & "\database\Basics"
    Dim srq As String = apppath & "\database\Basics\srq"
    Dim rrq As String = apppath & "\database\Basics\rrq"
    Dim airq As String = apppath & "\database\Basics\airq"
    'All things that require responces will be handle over here
    Public Function RequireReply(ByVal message As String)
        'Dim expressioncode As Integer = 0
        'Return expressioncode
        Return 1
    End Function
    ''''''''CORE MESSAGE DECOMPOSIOTION SYSTEM

    Public Function DecompileMessage(ByVal message As String)
        Dim reply As String = ""

        Return reply
    End Function

    Public Function NullKeyExisits(ByVal NullWords As String)
        Dim result As Boolean = False
        If fm.ReadFile(Basics & "\NullKeys.aroz").ToString.Contains(NullWords) = True Then
            result = True
        End If
        Return result
    End Function
    Public Function TrueKeyExists(ByVal KeysWords As String)
        Dim result As Boolean = False
        If fm.ReadFile(Basics & "\TrueKeys.aroz").ToString.Contains(KeysWords) = True Then
            result = True
        End If
        Return Result
    End Function


    ''''''''SEPERATING LINES''''''''''
    'Search Answer in Standard Responce Question
    Public Function GetAnswer(ByVal message As String)

    End Function

End Class
