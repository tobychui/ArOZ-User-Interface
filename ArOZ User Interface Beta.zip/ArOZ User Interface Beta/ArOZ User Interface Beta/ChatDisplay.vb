﻿Imports System.Text

Public Class ChatDisplay
    Dim apppath As String = Application.StartupPath
    Dim fm As New FileManagent
    Private Sub ChatInput_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Setting background and location
        Me.BackgroundImage = fm.LoadBitMap("ChatDisplayBG")
        Me.Top = Main_Action3d.Top + 15
        Me.Left = Main_Action3d.Left - 340
        Label1.Parent = Me
        'Count down to autoshut
        AutoClose.Enabled = True
    End Sub

    Private Sub AutoClose_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AutoClose.Tick
        Me.Hide()
        AutoClose.Enabled = False
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click
        Me.Hide()
    End Sub

    Private Sub Update_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Updates.Tick
        Me.Top = Main_Action3d.Top + 15
        Me.Left = Main_Action3d.Left - 340
    End Sub
    Public Sub DisplayMessage(ByVal message As String, Optional ByVal interfacecode As Integer = 4)
        Me.Top = Main_Action3d.Top + 15
        Me.Left = Main_Action3d.Left - 340
        Label1.Parent = Me
        Me.Show()
        Label1.Text = message
        Main_Action3d.SetInterfaceCode(interfacecode)
        AutoClose.Enabled = True
    End Sub

    Public Sub ReadDialog(ByVal dialogname As String)
        Dim filename As String = apppath & "\database\script\dialog\" & dialogname & ".txt"
        Dim code As String = Nothing
        Dim spacetime As Integer = 3
        Dim randomnumber As Integer = 0
        Dim selectedrandom As Integer = 0
        Dim expression As Integer = 4
        If System.IO.File.Exists(filename) = True Then

            Dim objReader As New System.IO.StreamReader(filename, System.Text.Encoding.GetEncoding(950))
            Dim sb As New StringBuilder
            Do While (objReader.Peek() <> -1)
                code = objReader.ReadLine()
                If code.Contains("[SETINT=") Then
                    spacetime = code.Substring(8, code.LastIndexOf("]") - 8)
                    GoTo Jumploop
                End If
                If code.Contains("[SETRAN=") Then
                    randomnumber = code.Substring(8, code.LastIndexOf("]") - 8)
                    Dim dc As New DataCalculations
                    selectedrandom = dc.Random(0, randomnumber)
                    Do Until code = "[RAN=" & selectedrandom & "]"
                        code = objReader.ReadLine()
                        ' MsgBox(code)
                    Loop

                    code = objReader.ReadLine()
                End If
                If code.Contains("[[") And code.Contains("]]") Then
                    expression = code.Substring(code.LastIndexOf("[[") + 2, code.LastIndexOf("]]") - code.LastIndexOf("[[") - 2)
                    code = code.ToString.Replace("[[" & expression.ToString & "]]", "")
                End If
                If code.Contains("[ENDRAN]") Then
                    GoTo StopLoop
                End If
                DisplayMessage(code.ToString, expression)
                AutoClose.Enabled = False
                Dim looptime As Integer = 0
                Do Until looptime = spacetime
                    Application.DoEvents()
                    System.Threading.Thread.Sleep(1)
                    looptime += 1
                Loop
Jumploop:
            Loop
            objReader.Dispose()

        Else

        End If
StopLoop:
        Main_Action3d.SetInterfaceCode(4)
        AutoClose.Enabled = True
    End Sub
End Class